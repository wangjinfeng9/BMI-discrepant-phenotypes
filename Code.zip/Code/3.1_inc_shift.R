# Incidence of CVD, CKD, and T2DM
library(readr)
library(dplyr, warn.conflicts = FALSE)
library(tidyr, warn.conflicts = FALSE)
library(purrr)
library(ggplot2)
library(Matrix,  warn.conflicts = FALSE)
library(lme4, warn.conflicts = FALSE)
library(lmerTest, warn.conflicts = FALSE)

load("../data/validclusmod.RData")
print(validclusmod)

set.seed(123)
cluscolmap <- validclusmod %>%
  dplyr::transmute(
    clusmod = purrr::map(clusmod, ~dplyr::select(.x, Cluster = validclus_name, W = validclus_weights))
  ) %>%
  tidyr::unnest(clusmod) %>%
  dplyr::group_by(Cluster) %>%
  dplyr::summarise(W2 = exp(sum(log(W)))) %>%
  dplyr::arrange(-W2) %>%
  dplyr::mutate(
    Cluster = factor(Cluster, levels = Cluster),
    ClusCol = scales::hue_pal()(n())
  )
cluscolmap

## Importing results
result_tab <- tibble(
  cohort = c("4C", "XJ", "SN", "CH")
)
result_tab

result_tab <- result_tab %>%
  mutate(
    data = map(
      cohort,
      ~tryCatch(rio::import(paste0("../data/", .x, "/result_file2.RData")),
                error = \(e) NULL)
    )
  )
print(result_tab)

result_long <- result_tab %>%
  expand_grid(
    element_name = c(
      "SurvSum",
      "RatesByClus",
      "RatesByClusMeds",
      "SurvCoefs",
      "ComparisonCVD",
      "ComparisonCKDDM"
    )
  ) %>%
  transmute(
    cohort, element_name,
    element_value = map2(
      data, element_name,
      ~.x[[.y]]
    )
  ) %>%
  filter(!map_lgl(element_value, is.null))
print(result_long)

result_long <- result_long %>%
  group_by(element_name) %>%
  summarise(
    element_value = list(
      bind_rows(
        map2(
          element_value, cohort, 
          ~mutate(.x, cohort = .y, .before = 1)
        )
      )
    )
  )
print(result_long)


## Estimates from log-contrast models
survcoefd <- result_long %>% 
  filter(element_name == "SurvCoefs") %>%
  dplyr::select(-element_name) %>%
  unnest(element_value) #%>%
#filter(fut == 10)
print(survcoefd)

logratioest <- survcoefd %>%
  filter(model == "clus") %>%
  transmute(
    cohort, sex, outcome, fut,
    estimates = map2(
      estimates, varcovmat,
      ~{
        cls <- grep("alrprob", names(.x), value = TRUE)
        data.frame(
          Cluster = gsub("alrprob", "", cls), 
          ESTIMATE = .x[cls],
          SE = sqrt(diag(.y)[cls])
        )
      }
    )
  ) %>%
  unnest(estimates)
head(logratioest)

poollogratioest <- logratioest %>%
  nest(D = -c(sex, outcome, Cluster, fut)) %>%
  mutate(
    D = map(D, ~meta::metagen(TE = .x$ESTIMATE, seTE = .x$SE)),
    D = map(
      D, 
      ~tibble(
        cohort = c("Pooled_FE", "Pooled_RE"),
        ESTIMATE = c(.x$TE.fixed, .x$TE.random), 
        SE = c(.x$seTE.fixed, .x$seTE.random),
        Qstat = .x$Q, Qdf = .x$df.Q, Qpval = .x$pval.Q
      )
    )
  ) %>%
  unnest(D)
head(poollogratioest)

poollogratioest <- poollogratioest %>%
  filter(cohort == "Pooled_RE") %>%
  transmute(
    sex, outcome, fut, Cluster, cohort,
    pvalfdr = p.adjust(2*pnorm(-abs(ESTIMATE/SE)), "fdr") < 0.05
  ) %>%
  right_join(poollogratioest)
head(poollogratioest)

alllogratioest <- poollogratioest %>%
  bind_rows(logratioest) %>%
  mutate(
    cohort = factor(
      case_match(
        cohort,
        "4C" ~ "4C_2011",
        "XJ" ~ "XJ_2011",
        "SN" ~ "SN_2009",
        "CH" ~ "CHARLS",
        .default = cohort
      ),
      levels = c("4C_2011","XJ_2011","SN_2009","CHARLS","Pooled_FE", "Pooled_RE")
    ),
    PVALUE = 2*pnorm(-abs(ESTIMATE/SE)),
    LOWERCI = ESTIMATE - qnorm(.975)*SE,
    UPPERCI = ESTIMATE + qnorm(.975)*SE,
  ) %>%
  transmute(
    sex, outcome, Cluster, fut, cohort,
    across(-c(pvalfdr, Qstat, Qdf, Qpval)),
    across(
      c(pvalfdr, Qstat, Qdf, Qpval),
      ~ifelse(cohort == "Pooled_RE", .x, NA)
    )
  ) %>%
  arrange(sex, outcome, Cluster, fut, cohort)
head(alllogratioest)

write_tsv(alllogratioest, "../data/alllogratioest.tsv")


options(repr.plot.width = 6.5, repr.plot.height = 8)
alllogratioest %>%
  mutate(Cluster = factor(Cluster, levels = c("NSF","HBP", "HTG", "HFG", "HSCR", "HHDL"))) %>%
  mutate(cohort = factor(cohort, levels = c("4C_2011","XJ_2011","SN_2009","CHARLS","Pooled_FE", "Pooled_RE")))  %>%
  filter(fut=="10") %>%
  ggplot(aes(ESTIMATE, reorder(cohort, desc(cohort)))) +
  geom_vline(xintercept = 0, lty = "dashed") +
  geom_linerange(aes(xmin = LOWERCI, xmax = UPPERCI)) +
  geom_point(aes(shape = grepl("Pooled", cohort)), show.legend = FALSE) +
  scale_shape_manual(values = c(20, 23)) +
  ggh4x::facet_nested(
    sex + Cluster ~ outcome , #+ fut
    scales = "free", independent = "x", space = "free_y"
  ) +
  scale_x_continuous(n.breaks = 4, labels = \(x)round(x, 2)) +
  labs(x = "Estimate\n95% CI", y = NULL) +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 5),
    axis.text.y = element_text(size = 6)
  )


#Given that shifts also represent changes in biomarker values, we need to recreate all biomarker values that would cause the shift.
### Effect of 10% shift in cluster probability from concordant to discordant clusters
shift10pc <- validclusmod %>%
  transmute(
    sex,
    ResD = map(
      clusmod,
      function(CLUSMOD){
        CLUSMOD %>%
          expand_grid(
            Cluster = CLUSMOD$validclus_name
          ) %>%
          mutate(
            toadd = case_when(
              Cluster == "NSF" ~ 0,
              Cluster == validclus_name ~ .1,
              validclus_name == "NSF" ~ -.1,
              TRUE ~ 0
            ),
            validclus_weights = validclus_weights + toadd
          ) %>%
          group_by(Cluster) %>%
          summarise(
            RGD = list(
              MGMM::rGMM(
                n = 5e5, 
                d = length(validclus_centers[[1]]),
                k = n(),
                pi = validclus_weights,
                means = validclus_centers, 
                covs = validclus_covmats
              ) %>%
                colMeans %>%
                round(2) %>%
                setNames(
                  names(validclus_centers[[1]])
                )
            )
          )
      }
    ),
    NewD = pmap(
      list(ResD, residmod, clusmod),
      function(D, RESIDMOD, CLUSMOD){
        D %>%
          mutate(
            predprobs = map(
              RGD, 
              ~{
                pdfs <- mapply(
                  function(mu, covmat){ 
                    mvtnorm::dmvnorm(
                      .x, mu, covmat
                    ) 
                  },
                  CLUSMOD$validclus_centers, 
                  CLUSMOD$validclus_covmats
                )
                L <- pdfs %*% diag(CLUSMOD$validclus_weights)
                colnames(L) <- CLUSMOD$validclus_name
                L / rowSums(L)
              }
            ),
            alrprobs = map(
              predprobs,
              ~{
                cclus <- colnames(.x) == "NSF"
                alrp <- .x[,!cclus]/.x[,cclus]
                names(alrp) <- paste0("alrprob", names(alrp))
                t(alrp)
              }
            ),
            actualbmvals = map(
              RGD,
              ~tibble(
                Biomarker = names(.x), sdresidval = .x
              ) %>%
                inner_join(RESIDMOD, by = "Biomarker") %>%
                mutate(
                  sdresid = sdresidval * SDRes,
                  bmi = 30 * bmi,
                  age = 60 * age,
                  bmvalue = rowSums(pick(Intercept, bmi, age, sdresid))
                ) %>%
                {setNames(.$bmvalue, .$Biomarker)} %>%
                c(bmi = 30, age = 60) %>% t
            ),
            joindat = map2(actualbmvals, alrprobs, cbind)
          ) %>%
          transmute(Cluster, joindat = map(joindat, data.frame)) %>%
          unnest(joindat)
      }
    ),
    NewD = map2(
      NewD, sex,
      ~mutate(
        .x, 
        tchol = hdl + ldl + (tg/2.2),
        age_tchol = 60*tchol,
        age_sbp = 60*sbp,
        age_hdl = 60*hdl
      )
    ),
    ResD
  )
print(shift10pc)

shift10est <- survcoefd %>%
  filter(model == "clus") %>%
  inner_join(shift10pc, by = "sex") %>%
  transmute(
    cohort,
    sex,
    outcome,
    fut,
    estdat = pmap(
      list(NewD, estimates, varcovmat),
      function(D, BETAS, COVM){
        Dmat <- as.matrix(select(D, -Cluster))
        rownames(Dmat) <- D$Cluster
        cclus <- rownames(Dmat) == "NSF"
        diffmat <- t(t(Dmat[!cclus,]) - Dmat[cclus,])
        nm <- intersect(colnames(diffmat), names(BETAS))
        covm <- COVM[nm,nm]
        data.frame(
          Cluster = gsub("alrprob", "", rownames(diffmat)),
          estimate = drop(diffmat[,nm] %*% BETAS[nm]),
          se = apply(
            diffmat[,nm], 1,
            \(clus){ 
              sqrt(drop(clus %*% covm %*% clus))
            }
          )
        )
      }
    )
  ) %>%
  unnest(estdat)
head(shift10est)

poolshift10est <- shift10est %>%
  nest(D = -c(sex, outcome, Cluster, fut)) %>%
  mutate(
    D = map(D, ~meta::metagen(TE = .x$estimate, seTE = .x$se,
                              method.tau = "DL",  # 使用更稳定的方法
                              control = list(maxiter = 1000, stepadj = 0.5))),
    D = map(
      D, 
      ~tibble(
        cohort = c("Pooled_FE", "Pooled_RE"),
        estimate = c(.x$TE.fixed, .x$TE.random), 
        se = c(.x$seTE.fixed, .x$seTE.random)
      )
    )
  ) %>%
  unnest(D)
head(poolshift10est)

allshift10est <- poolshift10est %>%
  bind_rows(shift10est) %>%
  mutate(
    cohort = factor(
      case_match(
        cohort,
        "4C" ~ "4C_2011",
        "XJ" ~ "XJ_2011",
        "SN" ~ "SN_2009",
        "CH" ~ "CHARLS",
        .default = cohort
      ),
      levels = c("4C_2011","XJ_2011","SN_2009", "CHARLS","Pooled_FE", "Pooled_RE")
    ),
    pval = 2*pnorm(-abs(estimate/se)),
    hr = exp(estimate),
    lwr = exp(estimate - qnorm(.975)*se),
    upr = exp(estimate + qnorm(.975)*se)
  ) %>%
  transmute(
    sex, outcome, Cluster, fut, cohort,
    across(everything())
  ) %>%
  arrange(sex, outcome, Cluster, fut, cohort)
head(allshift10est)

write_tsv(allshift10est, "../data/allshift10est.tsv")

options(repr.plot.width = 6.5, repr.plot.height = 8)
allshift10est %>%
  drop_na %>%
  mutate(
    Cluster = gsub("prob", "", Cluster),
    Cluster = factor(Cluster, levels = c("NSF","HBP", "HTG", "HFG", "HSCR", "HHDL"))
  ) %>%
  mutate(cohort = factor(cohort, levels = c("4C_2011","XJ_2011","SN_2009","CHARLS","Pooled_FE", "Pooled_RE")))  %>%
  filter(fut=="10") %>%
  ggplot(aes(hr, reorder(cohort, desc(cohort)))) +
  geom_vline(xintercept = 1, lty = "dashed") +
  geom_linerange(aes(xmin = lwr, xmax = upr)) +
  geom_point(aes(shape = grepl("Pooled", cohort)), show.legend = FALSE) +
  scale_shape_manual(values = c(20, 23)) +
  ggh4x::facet_nested(
    sex + Cluster ~ outcome , #+ fut
    scales = "free", independent = "x", space = "free_y"
    ) +
  scale_x_continuous(n.breaks = 4, labels = \(x)round(x, 2)) +
  labs(x = "HR", y = NULL) +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 5),
    axis.text.y = element_text(size = 6)
  )

options(repr.plot.width = 4, repr.plot.height = 4)
shift10estp <- poolshift10est %>%
  filter(cohort == "Pooled_RE") %>%
  mutate(
    hr = exp(estimate),
    lwr = exp(estimate - qnorm(.975)*se),
    upr = exp(estimate + qnorm(.975)*se),
    fut = factor(
      paste0(fut, "yr"), 
      levels = c("10yr", "5yr")
    ),
    Cluster = gsub("prob", "", Cluster),
    Cluster = factor(Cluster, levels = rev(c("NSF","HBP", "HTG", "HFG", "HSCR", "HHDL")))
  ) %>%
  ggplot(aes(hr, Cluster)) +
  geom_vline(xintercept = 1, lty = "dashed") +
  geom_linerange(
    aes(xmin = lwr, xmax = upr, group = fut),
    position = position_dodge(width = .5)
  ) +
  geom_point(
    aes(group = fut, color = fut),
    position = position_dodge(width = .5)
  ) +
  ggh4x::facet_nested(
    sex ~ outcome, scales = "free",
    independent = "x",
    space = "free_y"
  ) +
  labs(x = NULL, y = NULL, color = "Follow-up years") +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 5),
    legend.position = "top"
  )
shift10estp


## Shift of 20% from concordant to discordant
shift20pc <- validclusmod %>%
  transmute(
    sex,
    ResD = map(
      clusmod,
      function(CLUSMOD){
        CLUSMOD %>%
          expand_grid(
            Cluster = CLUSMOD$validclus_name
          ) %>%
          mutate(
            toadd = case_when(
              Cluster == "NSF" ~ 0,
              Cluster == validclus_name ~ .2,
              validclus_name == "NSF" ~ -.2,
              TRUE ~ 0
            ),
            validclus_weights = validclus_weights + toadd
          ) %>%
          group_by(Cluster) %>%
          summarise(
            RGD = list(
              MGMM::rGMM(
                n = 5e5, 
                d = length(validclus_centers[[1]]),
                k = n(),
                pi = validclus_weights,
                means = validclus_centers, 
                covs = validclus_covmats
              ) %>%
                colMeans %>%
                round(2) %>%
                setNames(
                  names(validclus_centers[[1]])
                )
            )
          )
      }
    ),
    NewD = pmap(
      list(ResD, residmod, clusmod),
      function(D, RESIDMOD, CLUSMOD){
        D %>%
          mutate(
            predprobs = map(
              RGD, 
              ~{
                pdfs <- mapply(
                  function(mu, covmat){ 
                    mvtnorm::dmvnorm(
                      .x, mu, covmat
                    ) 
                  },
                  CLUSMOD$validclus_centers, 
                  CLUSMOD$validclus_covmats
                )
                L <- pdfs %*% diag(CLUSMOD$validclus_weights)
                colnames(L) <- CLUSMOD$validclus_name
                L / rowSums(L)
              }
            ),
            alrprobs = map(
              predprobs,
              ~{
                cclus <- colnames(.x) == "NSF"
                alrp <- .x[,!cclus]/.x[,cclus]
                names(alrp) <- paste0("alrprob", names(alrp))
                t(alrp)
              }
            ),
            actualbmvals = map(
              RGD,
              ~tibble(
                Biomarker = names(.x), sdresidval = .x
              ) %>%
                inner_join(RESIDMOD, by = "Biomarker") %>%
                mutate(
                  sdresid = sdresidval * SDRes,
                  bmi = 30 * bmi,
                  age = 60 * age,
                  bmvalue = rowSums(pick(Intercept, bmi, age, sdresid))
                ) %>%
                {setNames(.$bmvalue, .$Biomarker)} %>%
                c(bmi = 30, age = 60) %>% t
            ),
            joindat = map2(actualbmvals, alrprobs, cbind)
          ) %>%
          transmute(Cluster, joindat = map(joindat, data.frame)) %>%
          unnest(joindat)
      }
    ),
    NewD = map2(
      NewD, sex,
      ~mutate(
        .x, 
        tchol = hdl + ldl + (tg/2.2),
        age_tchol = 60*tchol,
        age_sbp = 60*sbp,
        age_hdl = 60*hdl
      )
    ),
    ResD
  )
print(shift20pc)

shift20pc$NewD %>%
  map(select, -starts_with("alrprob"), -bmi, -age)

shift20est <- survcoefd %>%
  filter(model == "clus") %>%
  inner_join(shift20pc, by = "sex") %>%
  transmute(
    cohort,
    sex,
    outcome,
    fut,
    estdat = pmap(
      list(NewD, estimates, varcovmat),
      function(D, BETAS, COVM){
        Dmat <- as.matrix(select(D, -Cluster))
        rownames(Dmat) <- D$Cluster
        cclus <- rownames(Dmat) == "NSF"
        diffmat <- t(t(Dmat[!cclus,]) - Dmat[cclus,])
        nm <- intersect(colnames(diffmat), names(BETAS))
        covm <- COVM[nm,nm]
        data.frame(
          Cluster = gsub("alrprob", "", rownames(diffmat)),
          estimate = drop(diffmat[,nm] %*% BETAS[nm]),
          se = apply(
            diffmat[,nm], 1,
            \(clus){ 
              sqrt(drop(clus %*% covm %*% clus))
            }
          )
        )
      }
    )
  ) %>%
  unnest(estdat)
head(shift20est)

poolshift20est <- shift20est %>%
  nest(D = -c(sex, outcome, Cluster, fut)) %>%
  mutate(
    D = map(D, ~meta::metagen(TE = .x$estimate, seTE = .x$se)),
    D = map(
      D, 
      ~tibble(
        cohort = c("Pooled_FE", "Pooled_RE"),
        estimate = c(.x$TE.fixed, .x$TE.random), 
        se = c(.x$seTE.fixed, .x$seTE.random)
      )
    )
  ) %>%
  unnest(D)
head(poolshift20est)

allshift20est <- poolshift20est %>%
  bind_rows(shift20est) %>%
  mutate(
    cohort = factor(
      case_match(
        cohort,
        "4C" ~ "4C_2011",
        "XJ" ~ "XJ_2011",
        "SN" ~ "SN_2009",
        "CH" ~ "CHARLS",
        .default = cohort
      ),
      levels = c("4C_2011","XJ_2011","SN_2009", "CHARLS","Pooled_FE", "Pooled_RE")
    ),
    pval = 2*pnorm(-abs(estimate/se)),
    hr = exp(estimate),
    lwr = exp(estimate - qnorm(.975)*se),
    upr = exp(estimate + qnorm(.975)*se)
  ) %>%
  transmute(
    sex, outcome, Cluster, fut, cohort,
    across(everything())
  ) %>%
  arrange(sex, outcome, Cluster, fut, cohort)
head(allshift20est)

write_tsv(allshift20est, "../data/allshift20est.tsv")


options(repr.plot.width = 8, repr.plot.height = 8)
allshift20est %>%
  drop_na %>%
  mutate(
    Cluster = gsub("prob", "", Cluster),
    Cluster = factor(Cluster, levels = c("NSF","HBP", "HTG", "HFG", "HSCR", "HHDL"))
  ) %>%
  mutate(cohort = factor(cohort, levels = c("4C_2011","XJ_2011","SN_2009","CHARLS","Pooled_FE", "Pooled_RE")))  %>%
  filter(fut=="10") %>%
  ggplot(aes(hr, reorder(cohort, desc(cohort)))) +
  geom_vline(xintercept = 1, lty = "dashed") +
  geom_linerange(aes(xmin = lwr, xmax = upr)) +
  geom_point(aes(shape = grepl("Pooled", cohort)), show.legend = FALSE) +
  scale_shape_manual(values = c(20, 23)) +
  ggh4x::facet_nested(
    sex+Cluster~outcome, scales = "free", independent = "x",
    space = "free_y"
    # strip = ggh4x::strip_nested(
    #   background_x = ggh4x::elem_list_rect(
    #     fill = alpha(
    #       cluscolmap$ClusCol[cluscolmap$Cluster != "NSF"],
    #       .8
    #     )
    #   )
    # )
  ) +
  scale_x_continuous(n.breaks = 4, labels = \(x)round(x, 2)) +
  labs(x = NULL, y = NULL) +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 5)
  )

options(repr.plot.width = 4, repr.plot.height = 4)
poolshift20est %>%
  filter(cohort == "Pooled_RE") %>%
  mutate(
    hr = exp(estimate),
    lwr = exp(estimate - qnorm(.975)*se),
    upr = exp(estimate + qnorm(.975)*se),
    fut = factor(
      paste0(fut, "yr"), 
      levels = c("10yr", "5yr")
    ),
    Cluster = gsub("prob", "", Cluster),
    Cluster = factor(Cluster, levels = rev(c("NSF","HBP", "HTG", "HFG", "HSCR", "HHDL")))
  ) %>%
  ggplot(aes(hr, Cluster)) +
  geom_vline(xintercept = 1, lty = "dashed") +
  geom_linerange(
    aes(xmin = lwr, xmax = upr, group = fut),
    position = position_dodge(width = .5)
  ) +
  geom_point(
    aes(group = fut, color = fut),
    position = position_dodge(width = .5)
  ) +
  ggh4x::facet_nested(
    sex ~ outcome, scales = "free",
    independent = "x",
    space = "free_y"
  ) +
  labs(x =  NULL, y = NULL, color = "Follow-up years") +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 5),
    legend.position = "none"
  )


change_10 <- poolshift10est %>%
  filter(cohort == "Pooled_RE")%>%
  mutate(Group = "10% shift")

change_20 <- poolshift20est %>%
  filter(cohort == "Pooled_RE")%>%
  mutate(Group = "20% shift")

Change10and20 <- rbind(change_10,change_20)

Change10and20.d <- Change10and20 %>%
  mutate(
    hr = exp(estimate),
    lwr = exp(estimate - qnorm(.975)*se),
    upr = exp(estimate + qnorm(.975)*se))

write_tsv(Change10and20.d, "../data/Change10and20.d.tsv")

Change10and20 <- read.table("../data/Change10and20.d.tsv",header = T,sep = "\t")

options(repr.plot.width = 6, repr.plot.height = 4)
p1<- Change10and20 %>%
  filter(fut == 10) %>%
  mutate(
    hr = exp(estimate),
    lwr = exp(estimate - qnorm(.975)*se),
    upr = exp(estimate + qnorm(.975)*se),
    Group = factor(Group, levels = c("10% shift", "20% shift")),
    Cluster = gsub("prob", "", Cluster),
    Cluster = factor(Cluster, levels = rev(c("NSF","HBP", "HTG", "HFG", "HSCR", "HHDL"))),
    outcome = ifelse(outcome == "CKD", "Chronic Kidney Disease",
                     ifelse(outcome == "CVD", "Cardiovascular Disease",
                            ifelse(outcome == "T2DM", "Type 2 Diabetes",
                                   ifelse(outcome == "MI", "Myocardial Infarction",
                                          ifelse(outcome == "Stroke", "Stroke", NA))))),
    outcome = factor(outcome, levels = c("Type 2 Diabetes", "Chronic Kidney Disease", "Cardiovascular Disease","Stroke",
                                         "Myocardial Infarction" ))) %>%
  ggplot(aes(hr, Cluster)) +
  geom_vline(xintercept = 1, lty = "dashed") +
  geom_linerange(
    aes(xmin = lwr, xmax = upr, group = Group),
    position = position_dodge(width = .5)
  ) +
  geom_point(
    aes(group = Group, color = Group),
    position = position_dodge(width = .5)
  ) +
  scale_color_manual(values = c("10% shift" = "#1E64B4", "20% shift" = "#E63946")) +
  ggh4x::facet_nested(
    sex ~ outcome, 
    scales = "free", independent = "x", space = "free_y",
    strip = ggh4x::strip_nested(
      background_x = ggh4x::elem_list_rect(fill = "transparent"),
      background_y = ggh4x::elem_list_rect(fill = "transparent"),
      by_layer_y = FALSE
    )
  ) +
  labs(x = NULL, y = NULL, color = NULL) +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 10, angle = 45, hjust = 1),
    axis.title.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    strip.text = element_text(size = 10),
    legend.text = element_text(size = 12),
    legend.title = element_text(size = 10),
    legend.position = "top",
    plot.title = element_text(hjust = 0.5, size=14, face = "bold"),
    panel.spacing = unit(0.5, "lines")
  )
p1
