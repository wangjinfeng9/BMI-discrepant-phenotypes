library(readr)
library(dplyr, warn.conflicts = FALSE)
library(tidyr, warn.conflicts = FALSE)
library(purrr)
library(ggplot2)
library(Matrix,  warn.conflicts = FALSE)
library(lme4, warn.conflicts = FALSE)
library(lmerTest, warn.conflicts = FALSE)

load("../data/validclusmod.RData")
print(validclusmod)

set.seed(123)
cluscolmap <- validclusmod %>%
  dplyr::transmute(
    clusmod = purrr::map(clusmod, ~dplyr::select(.x, Cluster = validclus_name, W = validclus_weights))
  ) %>%
  tidyr::unnest(clusmod) %>%
  dplyr::group_by(Cluster) %>%
  dplyr::summarise(W2 = exp(sum(log(W)))) %>%
  dplyr::arrange(-W2) %>%
  dplyr::mutate(
    Cluster = factor(Cluster, levels = Cluster),
    ClusCol = scales::hue_pal()(n())
  )
cluscolmap


## Importing results
result_tab <- tibble(
  cohort = c("4C", "XJ", "SN", "CH")
)
result_tab

result_tab <- result_tab %>%
  mutate(
    data = map(
      cohort,
      ~tryCatch(rio::import(paste0("../data/", .x, "/result_file2.RData")),
                error = \(e) NULL)
    )
  )
print(result_tab)

result_long <- result_tab %>%
  expand_grid(
    element_name = c(
      "RatesByClus",
      "CountCovars"
    )
  ) %>%
  transmute(
    cohort, element_name,
    element_value = map2(
      data, element_name,
      ~.x[[.y]]
    )
  ) %>%
  filter(!map_lgl(element_value, is.null))
print(result_long)

result_long <- result_long %>%
  group_by(element_name) %>%
  summarise(
    element_value = list(
      bind_rows(
        map2(
          element_value, cohort, 
          ~mutate(.x, cohort = .y, .before = 1)
        )
      )
    )
  )
print(result_long)

## Risk of CVD in discordant clusters relative to concordant cluster
ratesbyclusdf <- result_long %>%
  filter(element_name == "RatesByClus") %>%
  dplyr::select(-element_name) %>%
  unnest(element_value) %>%
  filter( fut == 10)
head(ratesbyclusdf)

rrbycohort <- ratesbyclusdf %>%
  nest(D = -c(cohort, sex, outcome, fut)) %>%
  mutate(
    D = map(
      D,
      ~mutate(
        .x,
        Cluster=as.factor(Cluster),
        Cluster=relevel(Cluster, ref = "probNSF")
      )),
    mod = map(
      D,
      ~glm(round(Ncases) ~ Cluster + offset(log(TPT)), data = .x, family = poisson)
    ),
    mod = map(mod, broom::tidy),
    mod = map(mod, mutate, term = gsub("Cluster", "", term), statistic = NULL),
    mod = map2(D, mod, left_join, by = c("Cluster" = "term")),
    D = NULL
  ) %>%
  unnest(mod)
head(rrbycohort)

poolrrFE <- ratesbyclusdf %>%
  nest(D = -c(sex, outcome, fut)) %>%
  mutate(
    D = map(
      D,
      ~mutate(
        .x,
        Cluster=as.factor(Cluster),
        Cluster=relevel(Cluster, ref = "probNSF")
      )),
    D = map(
      D,
      ~{
        mod <- glm(
          round(Ncases) ~ Cluster + offset(log(TPT)), 
          data = .x, 
          family = poisson
        ) %>%
          broom::tidy() %>%
          mutate(
            term = gsub("Cluster", "", term), 
            statistic = NULL
          )
        dat <- .x %>%
          group_by(Cluster) %>%
          summarise(across(c(Ncases, TPT), sum))
        left_join(dat, mod, by = c("Cluster" = "term"))
      }
    )
  ) %>%
  unnest(D)
head(poolrrFE)

poolrrRE <- ratesbyclusdf %>%
  nest(D = -c(sex, outcome, fut)) %>%
  mutate(
    D = map(
      D,
      ~mutate(
        .x,
        Cluster=as.factor(Cluster),
        Cluster=relevel(Cluster, ref = "probNSF")
      )),
    D = map(
      D,
      ~{
        mod <- glmer(
          round(Ncases) ~ Cluster + offset(log(TPT)) + (1|cohort), 
          data = .x, 
          family = poisson,
          control = glmerControl(
            optimizer = "bobyqa",  
            optCtrl = list(maxfun = 100000)  
          )
        ) %>%
          broom.mixed::tidy() %>%
          mutate(
            term = gsub("Cluster", "", term), 
            across(c(effect, group, statistic), \(x) NULL)
          )
        dat <- .x %>%
          group_by(Cluster) %>%
          summarise(across(c(Ncases, TPT), sum))
        left_join(dat, mod, by = c("Cluster" = "term"))
      }
    )
  ) %>%
  unnest(D)
head(poolrrRE)

allRRs <- bind_rows(
  PooledFE = poolrrFE,
  PooledRE = poolrrRE,
  .id = "cohort"
) %>%
  bind_rows(rrbycohort) %>%
  mutate(
    cohort = factor(
      case_match(
        cohort,
        "4C" ~ "4C_2011",
        "XJ" ~ "XJ_2011",
        "SN" ~ "SN_2009",
        "CH" ~ "CHARLS",
        .default = cohort
      ),
      levels = c("4C_2011","XJ_2011","SN_2009", "CHARLS", "PooledFE", "PooledRE")
    ),      
    RR = exp(estimate),
    LOWERCI = exp(estimate - qnorm(1 - .05/2)*std.error),
    UPPERCI = exp(estimate + qnorm(1 - .05/2)*std.error)
  ) %>%
  arrange(sex, outcome, Cluster, fut, cohort)
head(allRRs, 10)
nrow(allRRs)

write_tsv(allRRs, "../data/allRRs.tsv")
allRRs.d <- allRRs %>%
  filter(cohort=="PooledRE",fut==10)
write_tsv(allRRs.d, file = "../data/allRRs.d.tsv")

####  Prevalence of Follow_Up diseases(CKD, T2DM) by cohort ####  
result_long %>%
  filter(element_name == "CountCovars") %>%
  unnest(element_value) %>%
  filter(
    Covariate %in% c(
      "T2DM","CKD"
    )
  ) %>%
  group_by(cohort, sex, Covariate) %>%
  summarise(
    across(c(Ncases, Nnoncases), sum),
    .groups = "drop"
  ) %>%
  mutate(Prop = round(100 * Ncases/(Ncases+Nnoncases), 2)) %>%
  select(-c(Ncases, Nnoncases)) %>%
  pivot_wider(names_from = cohort, values_from = Prop)

## ORs of diseases relative to concordant cluster    
percohortORs_followup <- result_long %>%
  filter(element_name == "CountCovars") %>%
  unnest(element_value) %>%
  filter(
    Covariate %in% c(
      "T2DM","CKD"
    )
  ) %>%
  select(-c(element_name, Nclus)) %>%
  nest(D = -c(sex, cohort, Covariate)) %>%
  mutate(
    Covariate = factor(
      Covariate,
      levels = c(
        "T2DM","CKD"
      )
    ),
    D = map(
      D,
      ~mutate(
        .x,
        Cluster=as.factor(Cluster),
        Cluster=relevel(Cluster, ref = "probNSF")
      )),
    mod = map(
      D, 
      ~glm(
        cbind(round(Ncases), round(Nnoncases)) ~ Cluster, 
        data = .x, family = "binomial"
      )
    )
  ) %>%
  mutate(
    mod = map(mod, broom::tidy),
    mod = map(mod, mutate, term = gsub("Cluster", "", term)),
    D = map2(D, mod, left_join, by = c("Cluster" = "term")),
    mod = NULL
  ) %>%
  unnest(D) %>%
  arrange(sex, cohort, Covariate)
head(percohortORs_followup)

pooledORs_followup <- result_long %>%
  filter(element_name == "CountCovars") %>%
  unnest(element_value) %>%
  filter(
    Covariate %in% c(
      "T2DM","CKD"
    )
  ) %>%
  select(-c(element_name, Nclus)) %>%
  nest(D = -c(sex, Covariate)) %>%
  mutate(
    Covariate = factor(
      Covariate,
      levels = c(
        "T2DM","CKD"
      )
    ),
    D = map(
      D,
      ~mutate(
        .x,
        Cluster=as.factor(Cluster),
        Cluster=relevel(Cluster, ref = "probNSF")
      )),
    Pooled_FE = map(
      D,
      ~if(length(unique(.x$cohort)) > 1){
        glm(
          cbind(round(Ncases), round(Nnoncases)) ~ Cluster, 
          data = .x, family = binomial
        )
      } else {
        NULL
      }                
    ),
    Pooled_RE = map(
      D,
      ~if(length(unique(.x$cohort)) > 1){
        glmer(
          cbind(round(Ncases), round(Nnoncases)) ~ Cluster + (1|cohort), 
          data = .x, family = binomial
        )
      } else {
        NULL
      }                
    )
  ) %>%
  pivot_longer(c(Pooled_FE, Pooled_RE), names_to = "cohort", values_to = "mod") %>%
  filter(!map_lgl(mod, is.null)) %>%
  mutate(
    mod = map2(cohort, mod, ~if(.x == "Pooled_FE"){ broom::tidy(.y) } else { broom.mixed::tidy(.y) }),
    mod = map(mod, mutate, term = gsub("Cluster", "", term)),
    D = map(D, group_by, Cluster),
    D = map(D, summarise, across(c(Ncases, Nnoncases), sum)),
    D = map2(D, mod, left_join, by = c("Cluster" = "term")),
    mod = NULL
  ) %>%
  unnest(D) %>%
  select(-any_of(c("effect", "group"))) %>%
  arrange(sex, Covariate)
head(percohortORs_followup)

allORs_followup <- pooledORs_followup %>%
  bind_rows(percohortORs_followup) %>%
  transmute(
    sex, Covariate, 
    cohort = factor(
      case_match(
        cohort,
        "4C"  ~ "4C_2011",
        "XJ"  ~ "XJ_2011",
        "SN"  ~ "SN_2009",
        "CH" ~ "CHARLS",
        .default = cohort
      ),
      levels = c("4C_2011", "XJ_2011", "SN_2009", "CHARLS", "Pooled_FE", "Pooled_RE")
    ),      
    Cluster = gsub("prob", "", Cluster), 
    across(everything()),
    OR = exp(estimate),
    LOWERCI = exp(estimate - qnorm(1 - .05/2)*std.error),
    UPPERCI = exp(estimate + qnorm(1 - .05/2)*std.error)
  ) %>%
  arrange(sex, Covariate, Cluster, cohort)
head(allORs_followup)
nrow(allORs_followup)

write_tsv(allORs_followup, "../data/allORs_followup.tsv")

## combined CVD and CKD/T2DM
library(readr)
allRRs <- read_tsv("../data/allRRs.d.tsv", show_col_types = FALSE)
allRRs.d <- allRRs %>%
  mutate(Cluster = gsub("prob", "", Cluster)) %>%
  mutate(Cluster = factor(Cluster, levels = cluscolmap$Cluster),
         estimate=RR,
         outcome=paste(outcome,"\nRR relative to NSF")
         # outcome=paste("RR (95%CI) of ",outcome,"\nrelative to NSF")
         ) %>%
  select(outcome,sex,Cluster,estimate,LOWERCI,UPPERCI) %>%
  drop_na

allORs <- read_tsv("../data/allORs_followup.tsv", show_col_types = FALSE)
allORs.d <- allORs %>%
  drop_na %>%
  filter(cohort %in% c("Pooled_RE")) %>%
  mutate(
    cohort = gsub("Pooled_", "", cohort),
    Cluster = factor(Cluster, levels = rev(cluscolmap$Cluster)),
    estimate=OR,
    outcome=paste(Covariate,"\nOR relative to NSF") 
    # outcome=paste("OR (95%CI) of ",Covariate,"\nrelative to NSF") 
  ) %>%  
  inner_join(cluscolmap, by = "Cluster") %>%
  select(outcome,sex,Cluster,estimate,LOWERCI,UPPERCI)

colnames(allRRs.d)
colnames(allORs.d)

color_map <- setNames(cluscolmap$ClusCol, cluscolmap$Cluster)
all_estimate <- rbind.data.frame(allRRs.d,allORs.d)
all_estimate%>%
  inner_join(cluscolmap, by = "Cluster") %>%
  mutate(Cluster = factor(Cluster, levels = rev(c("HBP", "HTG", "HFG", "HSCR", "HHDL")))) %>%
  mutate(
    outcome=ifelse(outcome=="CKD \nOR relative to NSF","Chronic kidney Disease",
                   ifelse(outcome=="CVD \nRR relative to NSF","Cardiovascular Disease",
                          ifelse(outcome=="T2DM \nOR relative to NSF","Type 2 Diabetes",
                                 ifelse(outcome=="MI \nRR relative to NSF","Myocardial infarction", 
                                        ifelse(outcome=="Stroke \nRR relative to NSF","Stroke", NA))))),
    outcome = factor(outcome, levels = c("Type 2 Diabetes","Chronic kidney Disease","Cardiovascular Disease", "Stroke","Myocardial infarction")),
    # outcome = factor(outcome, levels = c("T2DM \nOR relative to NSF", "CVD \nRR relative to NSF", "CKD \nOR relative to NSF")),
    bigeff = estimate > 10, xint = ifelse(bigeff, NA, 1),
  ) %>%
  ggplot(aes(estimate, Cluster, color = Cluster)) +
  geom_vline(aes(xintercept = xint), lty = "dashed", na.rm = TRUE) +
  geom_linerange(
    aes(xmin = LOWERCI, xmax = UPPERCI, color = Cluster),linewidth = 0.8
      
  ) +
  geom_point(size=2) +
  ggh4x::facet_nested(
    sex~ outcome + bigeff, scales = "free", space = "free",
    strip = ggh4x::strip_nested(
      size = "variable",
      background_x = list(element_rect(), element_rect(fill = NA, colour = NA)),
      text_x = list(element_text(), element_text(size = 0, margin = margin())),
      by_layer_x = TRUE
    )
  ) +
  ggh4x::force_panelsizes(cols = c(1, 1, 1, .5, 1, 1, .5, 1, 1)) +
  # ggh4x::scale_x_facet(!bigeff, n.breaks = 4, limits = c(0, NA)) +
  #ggh4x::scale_x_facet(bigeff, n.breaks = 4) +
  #coord_cartesian(xlim = c(0, 4.7)) +
  scale_color_manual(values = color_map) +
  labs(x = NULL, y = NULL, color = "Model") +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12),
    axis.title.x = element_text(size = 14),

    strip.text = element_text(size = 14),
    legend.position = "none"
  )+ scale_x_continuous(
    labels = scales::number_format(accuracy = 1),
    breaks = scales::breaks_width(1)
  )