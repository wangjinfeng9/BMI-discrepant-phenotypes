####Merging Metabolomics and Probability####
library(readr)
library(dplyr, warn.conflicts = FALSE)
library(tidyr, warn.conflicts = FALSE)
library(purrr)
library(ggplot2)
library(Matrix, warn.conflicts = FALSE)
library(uwot)

options(repr.plot.res = 300)

load("../data/validclusmod.RData")

print(validclusmod)

residtab <- rio::import("../data/4C/residtab.RData")
map(residtab, head)

validclusmod <- validclusmod %>%
  mutate(
    residtabs = map(
      sex,
      ~residtab[[.x]]
    )
  )
print(validclusmod)

BIOMARKERS <- c("sbp", "dbp", "scr", "hdl", "tg", "ldl", "fg")

validclusmod <- validclusmod %>%
  mutate(
    residtabs = map2(
      residtabs, clusmod,
      function(RESIDDF, CLUSMOD){
        RESDF <- select(RESIDDF, all_of(BIOMARKERS))
        pdfs <- mapply(
          function(mu, covmat){ mvtnorm::dmvnorm(RESDF, mu, covmat) },
          CLUSMOD$validclus_centers, 
          CLUSMOD$validclus_covmats
        )
        L <- pdfs %*% diag(CLUSMOD$validclus_weights)
        colnames(L) <- paste0("prob", CLUSMOD$validclus_name)
        bind_cols(RESIDDF, data.frame(L / rowSums(L)))
      }
    )
  )
print(validclusmod)

origprop <- validclusmod %>%
  transmute(
    sex,
    PropDF = map(
      residtabs,
      ~.x %>%
        summarise(across(starts_with("prob"), sum)) %>%
        pivot_longer(everything()) %>%
        mutate(N = sum(value), prop = value/N)
    )
  ) %>%
  unnest(PropDF)
origprop

all_prob_data <- validclusmod %>%
  select(sex, residtabs) %>%
  unnest(residtabs)

data_clean <- all_prob_data
data_clean[is.na(all_prob_data)] <- 0

max_idx <- max.col(data_clean[, 10:15])
cluster_names <- colnames(all_prob_data)[10:15]
all_prob_data$max_cluster <- cluster_names[max_idx]
write.csv(all_prob_data,"../data/sample_cluster_4C.csv")

#metabdata should include "eid", "age", "bmi",and metabolites
metabdata <- read.csv("../data/metabolites.csv")

merged_data <- inner_join(metabdata, all_prob_data, by = "eid")

merged_data <- merged_data %>%
  mutate(across(starts_with("prob"), 
                ~ ifelse(is.na(.) | is.na(probNSF), 
                         NA, 
                         log(. / probNSF)),
                .names = "alr_{.col}"))


#Multivariate linear regression model of metabolites and clustering probabilities
library(dplyr)
library(tidyr)
library(broom)
library(purrr)

perform_multiple_regression <- function(data, y_vars, sex_group) {
  
  if (sex_group == "Female") {
    subset_data <- data %>% filter(sex == "Female")  
    predictors <- "alr_probHTG + alr_probHFG + alr_probHSCR + alr_probHBP + age + bmi"
  } else if (sex_group == "Male") {
    subset_data <- data %>% filter(sex == "Male")  
    predictors <- "alr_probHTG + alr_probHFG + alr_probHHDL + alr_probHSCR + alr_probHBP + age + bmi"
  } else {
    stop("sex must be 'Female' or 'Male'")
  }
  
  results <- map_dfr(y_vars, function(y_var) {
    
    formula_str <- paste0(y_var, " ~ ", predictors)
    formula_obj <- as.formula(formula_str)
    
    tryCatch({
      model <- lm(formula_obj, data = subset_data, na.action = na.omit)
      
      tidy_results <- tidy(model, conf.int = TRUE) %>%
        mutate(
          y_variable = y_var,
          sex = sex_group,
          n_obs = nobs(model),
          r_squared = summary(model)$r.squared,
          adj_r_squared = summary(model)$adj.r.squared
        )
      
      return(tidy_results)
      
    }, error = function(e) {
      data.frame(
        term = NA_character_,
        estimate = NA_real_,
        std.error = NA_real_,
        statistic = NA_real_,
        p.value = NA_real_,
        conf.low = NA_real_,
        conf.high = NA_real_,
        y_variable = y_var,
        sex = sex_group,
        n_obs = 0,
        r_squared = NA_real_,
        adj_r_squared = NA_real_
      )
    })
  })
  
  return(results)
}

run_regression_analysis <- function(data) {
  
  #The column where the metabolite variables are located
  y_variables <- names(data)[3:142]
  
  required_vars <- c( "alr_probHTG",  "alr_probHFG", "alr_probHBP" , 
                     "alr_probHSCR", "alr_probHHDL", "age", "bmi", "sex")
  
  missing_vars <- setdiff(required_vars, names(data))
  if (length(missing_vars) > 0) {
    stop("missing variables: ", paste(missing_vars, collapse = ", "))
  }
  
  female_results <- perform_multiple_regression(data, y_variables, "Female")
  male_results <- perform_multiple_regression(data, y_variables, "Male")
  
  all_results <- bind_rows(female_results, male_results) %>%
    filter(!is.na(term))  
  
  return(all_results)
}


regression_results <- run_regression_analysis(merged_data)

print(head(regression_results))

#Metab_list should include metabolites_name and pathways (TL1	TL2	TL3	TL4 in our data)
Metab_list <- read.csv("../data/metabolites_marker.csv")
regression_results_fdr <- regression_results %>%
  left_join(Metab_list, by = c("y_variable" = "metabolites_name")) %>%
  filter(!is.na(TL1)) %>%
  group_by(sex, term) %>%
  mutate(
    p.value.fdr = p.adjust(p.value, method = "BH")) %>%
  ungroup()

####Counts of metabolites in each pathway
summarize_by_tl_levels_auto <- function(data, sex_group = c("Female", "Male")) {
  
  filtered_data <- data %>%
    filter(sex %in% sex_group)
  
  available_terms <- unique(filtered_data$term)
  target_terms_auto <- available_terms[available_terms %in% 
                                         c("alr_probHBP", "alr_probHTG", 
                                           "alr_probHFG", "alr_probHSCR", "alr_probHHDL")]
  
  filtered_data <- filtered_data %>%
    filter(term %in% target_terms_auto)
  
  tl_summaries <- list()
  
  if (nrow(filtered_data) > 0) {
    tl1_total_counts <- filtered_data %>%
      group_by(TL1) %>%
      summarise(
        category_total = n_distinct(y_variable),  
        .groups = "drop"
      ) %>%
      rename(category = TL1)
    
    tl1_summary <- filtered_data %>%
      group_by(TL1, term) %>%
      summarise(
        significant_count = sum(p.value.fdr < 0.05, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      pivot_wider(
        names_from = term,
        values_from = significant_count,
        values_fill = 0
      ) %>%
      mutate(TL_level = "TL1") %>%
      rename(category = TL1)
    
    tl1_summary <- tl1_summary %>%
      left_join(tl1_total_counts, by = "category") %>%
      select(TL_level, category, category_total, everything())
    
    tl_summaries[["TL1"]] <- tl1_summary
  }
  
 
  if (nrow(filtered_data) > 0) {
    tl2_total_counts <- filtered_data %>%
      group_by(TL2) %>%
      summarise(
        category_total = n_distinct(y_variable),
        .groups = "drop"
      ) %>%
      rename(category = TL2)
    
    tl2_summary <- filtered_data %>%
      group_by(TL2, term) %>%
      summarise(
        significant_count = sum(p.value.fdr < 0.05, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      pivot_wider(
        names_from = term,
        values_from = significant_count,
        values_fill = 0
      ) %>%
      mutate(TL_level = "TL2") %>%
      rename(category = TL2)
    
    tl2_summary <- tl2_summary %>%
      left_join(tl2_total_counts, by = "category") %>%
      select(TL_level, category, category_total, everything())
    
    tl_summaries[["TL2"]] <- tl2_summary
  }
  
  
  if (nrow(filtered_data) > 0) {
    tl3_total_counts <- filtered_data %>%
      group_by(TL3) %>%
      summarise(
        category_total = n_distinct(y_variable),
        .groups = "drop"
      ) %>%
      rename(category = TL3)
    
    tl3_summary <- filtered_data %>%
      group_by(TL3, term) %>%
      summarise(
        significant_count = sum(p.value.fdr < 0.05, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      pivot_wider(
        names_from = term,
        values_from = significant_count,
        values_fill = 0
      ) %>%
      mutate(TL_level = "TL3") %>%
      rename(category = TL3)
    
    tl3_summary <- tl3_summary %>%
      left_join(tl3_total_counts, by = "category") %>%
      select(TL_level, category, category_total, everything())
    
    tl_summaries[["TL3"]] <- tl3_summary
  }
  
  
  if (nrow(filtered_data) > 0) {
    tl4_total_counts <- filtered_data %>%
      group_by(TL4) %>%
      summarise(
        category_total = n_distinct(y_variable),
        .groups = "drop"
      ) %>%
      rename(category = TL4)
    
    tl4_summary <- filtered_data %>%
      group_by(TL4, term) %>%
      summarise(
        significant_count = sum(p.value.fdr < 0.05, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      pivot_wider(
        names_from = term,
        values_from = significant_count,
        values_fill = 0
      ) %>%
      mutate(TL_level = "TL4") %>%
      rename(category = TL4)
    
    tl4_summary <- tl4_summary %>%
      left_join(tl4_total_counts, by = "category") %>%
      select(TL_level, category, category_total, everything())
    
    tl_summaries[["TL4"]] <- tl4_summary
  }
  
  
  if (length(tl_summaries) > 0) {
    combined_summary <- bind_rows(tl_summaries) %>%
      filter(!is.na(category) & category != "") %>%  
      arrange(TL_level, category)
    
    all_possible_terms <- c("alr_probHBP", "alr_probHTG", 
                            "alr_probHFG", "alr_probHSCR", "alr_probHHDL")
    missing_terms <- setdiff(all_possible_terms, names(combined_summary))
    
    for (term in missing_terms) {
      combined_summary[[term]] <- 0
    }
    
    combined_summary <- combined_summary %>%
      select(TL_level, category, category_total, all_of(all_possible_terms))
    
    total_significant_counts <- filtered_data %>%
      group_by(term) %>%
      summarise(
        total_sig = sum(p.value.fdr < 0.05, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      pivot_wider(
        names_from = term,
        values_from = total_sig,
        values_fill = 0
      )
    
    summary_row <- data.frame(
      TL_level = "Total",
      category = "All Categories",
      category_total = n_distinct(filtered_data$y_variable),  
      stringsAsFactors = FALSE
    )
    
    
    for (term in all_possible_terms) {
      if (term %in% names(total_significant_counts)) {
        summary_row[[term]] <- total_significant_counts[[term]][1]
      } else {
        summary_row[[term]] <- 0
      }
    }
    
    
    combined_summary_with_total <- bind_rows(summary_row, combined_summary)
    
    return(combined_summary_with_total)
  } else {
    return(data.frame())
  }
}


female_summary_auto <- summarize_by_tl_levels_auto(regression_results_fdr, "Female")
male_summary_auto <- summarize_by_tl_levels_auto(regression_results_fdr, "Male")


create_unified_summary <- function(female_data, male_data) {
  
  female_with_sex <- female_data %>% mutate(sex = "Female")
  male_with_sex <- male_data %>% mutate(sex = "Male")
  
  unified_summary <- bind_rows(female_with_sex, male_with_sex) %>%
    select(sex, TL_level, category, category_total, everything())
  
  return(unified_summary)
}


unified_summary <- create_unified_summary(female_summary_auto, male_summary_auto)

write.csv(unified_summary, "../data/p.value.fdr_significance_summary_with_counts.csv", row.names = FALSE)

###enrichment analysis###
Data <- unified_summary %>%
  filter(sex == "Female") %>%
  select(-(1:2)) %>%
  column_to_rownames(var = names(.)[1])

pvalue <- matrix(NA, nrow(Data), ncol(Data))
rownames(pvalue) <- rownames(Data)
colnames(pvalue) <- colnames(Data)
for (i in 2:nrow(Data)) {
  for (j in 2:ncol(Data)) {
    p <- phyper(Data[i,j]-1, Data[1,j], Data[1,1]-Data[1,j], Data[i,1], lower.tail=F)
    pvalue[i,j] <- p
  }
}
female_pvalue <- as.data.frame(pvalue) %>%
  mutate(sex = "Female", .before = 1) %>%
  rownames_to_column(var = "Pathway")

Data <- unified_summary %>%
  filter(sex == "Male") %>%
  select(-(1:2)) %>%
  column_to_rownames(var = names(.)[1])

pvalue <- matrix(NA, nrow(Data), ncol(Data))
rownames(pvalue) <- rownames(Data)
colnames(pvalue) <- colnames(Data)
for (i in 2:nrow(Data)) {
  for (j in 2:ncol(Data)) {
    p <- phyper(Data[i,j]-1, Data[1,j], Data[1,1]-Data[1,j], Data[i,1], lower.tail=F)
    pvalue[i,j] <- p
  }
}
male_pvalue <- as.data.frame(pvalue) %>%
  mutate(sex = "Male", .before = 1) %>%
  rownames_to_column(var = "Pathway")

combined_pvalue <- rbind(female_pvalue, male_pvalue)

write.csv(combined_pvalue, file = "../data/FDR_Enrichment analysis p-value.csv")
