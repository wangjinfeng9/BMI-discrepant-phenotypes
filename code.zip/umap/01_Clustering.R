library(tibble)
library(readr)
library(dplyr)
library(tidyr)
library(purrr)
library(uwot)
library(igraph)
library(mvtnorm)

recoded_dat <- read_tsv("../data/recoded_dat.tsv", show_col_types = FALSE)

# The units of the contiuous variables we expect to run the analysis:
# - Age in years.
# - Sex as a string of either "Female" or "Male".
# - BMI in kg/m2.
# - SBP and DBP in mmHg.
# - SCR in umol/L.
# - HDL in mmol/L.
# - TG in mmol/L.
# - LDL in mmol/L.
# - FG in mmol/L.
# - Smoking as a dummy variable: 1 if currently smoking, 0 otherwise.

# the input data should only contain individuals who have all biomarker values.
# In discovery and validation cohorts we will exclude biomarker measurements that are 5 SD away from the mean, under the assumption that these are most likely measurement errors.

## Remove possible errors in measurement
recoded_dat <- mutate(recoded_dat, 
                      across(c(bmi, sbp, dbp, scr, hdl, tg, ldl, fg), 
                             ~remove_outliers(.x, sdunits = 5)))
recoded_dat <- recoded_dat[complete.cases(recoded_dat),]

## Stratify by sex
strat_dat <- split(recoded_dat, ~sex)
lapply(strat_dat, head)

## Summary of initial input
gendesc_tab <- get_general_descriptives(strat_dat)
gendesc_tab

## Generate sex-specific linear models of BMI for each variable, adjusting for age, and smoking
mods <- get_bmimods(strat_dat)
print(mods)

bmicoefs_tab <- get_bmicoefs(mods)
bmicoefs_tab

## Generate table with residual values
residtab <- get_residtabs(strat_dat, mods)
lapply(residtab, head)

## Obtaining clusters and probabilities of allocation
cluster_results <- get_cluster_results(residtab)
lapply(cluster_results, names)

umap_models <- get_umap_mod(cluster_results)
cluster_results <- clean_cluster_results(cluster_results)

## Table summarising clusters
clustersummary <- get_clustersummary(cluster_results)
head(clustersummary)

cluster_descriptives <- get_cluster_descriptives(cluster_results, strat_dat)
head(cluster_descriptives)

## Relationship between BMI and biomarkers in ea4C cluster
clusbmicoefs <- get_bmicoefs_clusters(cluster_results, strat_dat)
head(clusbmicoefs)

## Gathering and saving results
result_file <- list(
  General_descriptives = gendesc_tab,
  BMI_coefficients = bmicoefs_tab,
  Cluster_results = cluster_results,
  Cluster_summary = clustersummary,
  Cluster_descriptives = cluster_descriptives,
  Cluster_BMI_coefficients = clusbmicoefs
)
save(result_file, file = "../data/4C/result_file.RData")

## Saving other objects generated
save(strat_dat, file = "../data/4C/strat_dat.RData") #The inputa data, not residualised
save(residtab, file = "../data/4C/residtab.RData")   #The input data, residualised

##The UMAP models
iwalk(
  umap_models,
  ~save_uwot(
    model = .x, 
    file = paste0("../data/4C/umapmod_", .y)
  )
)
