library(readr)
library(dplyr, warn.conflicts = FALSE)
library(tidyr, warn.conflicts = FALSE)
library(purrr)
library(survival)
library(writexl)
library(survIDINRI)
library(nricens)
library(ResourceSelection)

#The input table is the same table of 10 traits we had prior to run UMAP.
#including eid,sbp,dbp,hdl,ldl,tg,fg,scr,smoking,sex,age
load("../data/4C/strat_dat.RData")
map(strat_dat, head)

### Table of validated clusters
# The second thing needed is the clusters we have validated.
load("../data/validclusmod.RData")
print(validclusmod)

### Table of pre-existing conditions and medications
#The third thing we need is a table of pre-existing conditions and medications participants are currently taking
covar_dat <- read.table("../data/covar_dat.txt",header = T,sep = "\t")

### Survival data for cvd progression
survcvddat <- read.table("../data/survcvddat.txt",header = T,sep = "\t")
survmidat <- read.table("../data/survmidat.txt",header = T,sep = "\t")
survstrokedat <- read.table("../data/survstrokedat.txt",header = T,sep = "\t")
#These tables should be restricted to individuals with a maximum follow‑up of 10 years.Any events occurring after 10 years were censored.
#The variable outcome_value was coded as 1 if the participant experienced the event during follow‑up and 0 otherwise, while outcome_timeyrs recorded the time from baseline to the first event or to censoring (at 10 years).
#During data preparation, for each outcome of interest, we set the outcome value to NA for participants who already had the disease at baseline, thereby excluding them from the incident‑event analysis. Consequently, these tables do not include individuals with baseline prevalence of the diseases under study.
survcvddat <- survcvddat %>% filter(!is.na(outcome_timeyrs)&!is.na(outcome_value))
survmidat <- survmidat %>% filter(!is.na(outcome_timeyrs)&!is.na(outcome_value))
survstrokedat <- survstrokedat %>% filter(!is.na(outcome_timeyrs)&!is.na(outcome_value))

## Calculation of cluster probabilities
clusterdfs <- clusterprobcalc(ClusModDf = validclusmod, StratDat = strat_dat)
print(clusterdfs)
head(clusterdfs$data[[1]])

## Descriptive statistics
#The distribution of biomarkers per cluster
markerdistribdf <- markerdistribfx(clusterdfs)
head(markerdistribdf)

#The effect of BMI on biomarkers specifically within each cluster
bmieffmarkerdf <- bmieffmarkerfx(clusterdfs)
head(bmieffmarkerdf)

## Prevalent diseases and medication
clusterdfs <- addcovardat(X = clusterdfs, CovarDat = covar_dat)
print(clusterdfs)
head(clusterdfs$data[[1]])

#count the number of individuals with disease and taking medications in each cluster
countcovarsdf <- countcovarsfx(clusterdfs)
head(countcovarsdf)

#the proportion of individuals receiving medications in each cluster, stratified by each condition
countdxmed <- countdxmedfx(clusterdfs)
head(countdxmed)

#the association between cluster allocation and diseases using logistic regressions where the outcome is each disease and the predictors are the cluster allocations
#two models for each disease: one with only clusters, and a second one adjusting for medication
assocdxdf <- assocdxfx(clusterdfs)
print(assocdxdf)

### Analysis of Disease Incidence
## Adding survival data
clustersurvdfs <- addsurvdat(X = clusterdfs, SurvMACEDf = survcvddat, SurvMIDf = survmidat, SurvSTDf = survstrokedat)
print(clustersurvdfs)

## Creating follow-up subsets
#In each subset the follow-up will be censored at a specific point in time
clustersurvdfs <- futsubsetsfx(clustersurvdfs)
print(clustersurvdfs)

## Summary of survival data
survsum <- survsumfx(clustersurvdfs)
survsum

## Rates of outcomes by cluster
#the number of cases and the total follow-up in each cluster (CVD)
ratesbyclus <- ratesclusfx(clustersurvdfs)
head(ratesbyclus)

#by medication status
ratesbyclusmed <- ratesclusmedfx(clustersurvdfs)
head(ratesbyclusmed)

# the number of incident cases of T2DM and CKD across clusters
prevalent_stats_df <- prevalent_stats(clusterdfs, diseases = c("CKD", "T2DM"))

#### Fitting models
#fit two models: one containing all biomarkers and another one containing the biomarkers plus the cluster probabilities.
#`mod_base` contains the baseline model, while `mod_clus` contains the baseline plus clusters model. `mod_null` contains the null model.
## Cox models
coxmoddf <- coxmodels(clustersurvdfs)
print(coxmoddf)

## logistic models
assocdxdf_long <- assocdxfx_long(clusterdfs)
print(assocdxdf_long)

##combine models
coxmoddf_merge <- rbind(assocdxdf_long,coxmoddf)
print(coxmoddf_merge)

#### Coefficient estimates
survcoefs <- survcoefx(coxmoddf_merge)
print(survcoefs)

#### Comparison of predictive ability
## Cox models
compmoddf <- comparemods(coxmoddf)
compmoddf <- compmoddf %>%
  unnest_wider(NRI_IDI)

coxmoddf_calib <- coxmoddf %>%
  mutate(
    Calib = pmap(
      list(mod_base, mod_clus, survdf, fut),
      function(m1, m2, dat, ft) {
        calibration_analysis(m1, m2, dat, ft, B = 200)
      }
    )
  )

coxmoddf_calib <- coxmoddf_calib %>%
  mutate(
    base_slope      = map_dbl(Calib, ~ .x$model1$slope),
    base_intercept  = map_dbl(Calib, ~ .x$model1$intercept),
    base_p          = map_dbl(Calib, ~ .x$model1$p.value),
    clus_slope      = map_dbl(Calib, ~ .x$model2$slope),
    clus_intercept  = map_dbl(Calib, ~ .x$model2$intercept),
    clus_p          = map_dbl(Calib, ~ .x$model2$p.value),
    diff_slope      = map_dbl(Calib, ~ .x$comparison$diff),
    diff_lower      = map_dbl(Calib, ~ .x$comparison$lower),
    diff_upper      = map_dbl(Calib, ~ .x$comparison$upper),
    diff_p          = map_dbl(Calib, ~ .x$comparison$p.value)
  )

compmoddf <- compmoddf %>%
  left_join(
    coxmoddf_calib %>%
      select(sex, outcome, fut, 
             base_slope, base_intercept, base_p,
             clus_slope, clus_intercept, clus_p,
             diff_slope, diff_lower, diff_upper, diff_p),
    by = c("sex", "outcome", "fut")
  )

compmoddf_CKDDM <- comparemods_CKDDM(assocdxdf_long)
compmoddf_CKDDM <- compmoddf_CKDDM %>% unnest_wider(NRI_IDI)

#### Decision curve analysis
dcares <- DCurvFx(coxmoddf)
head(dcares)

dcares_CKDDM <- DCurvFx_logistic(assocdxdf_long)
head(dcares_CKDDM)

dcares_combined <- dplyr::bind_rows(dcares, dcares_CKDDM)

## Saving data
result_file2 <- list(
  MarkerDistrib = markerdistribdf,
  BMIeffOnMarker = bmieffmarkerdf,
  CountCovars = countcovarsdf,
  CountDXMeds = countdxmed,
  CrossSectAssoc = assocdxdf,
  SurvSum = survsum,
  RatesByClus = ratesbyclus,
  RatesByClusMeds = ratesbyclusmed,
  PrevalentStats = prevalent_stats_df,
  SurvCoefs = survcoefs,
  ComparisonCVD = compmoddf,
  ComparisonCKDDM = compmoddf_CKDDM,
  DCARes = dcares_combined,
  models = coxmoddf_merge
)

save(
  result_file2,
  file = "../data/4C/result_file2.RData"
)

compmoddf_all <- bind_rows(
  compmoddf %>% mutate(Model = "Cox"),
  compmoddf_CKDDM %>% mutate(Model = "Logistic")
) %>%
  select(sex, outcome, fut, Model, everything()) %>%
  arrange(sex, outcome, fut)

write.csv(compmoddf_all,"../data/4C/compmoddf_final.csv")
