# Calculate the clustering probability at the 3.8-year follow-up period
library(readr)
library(dplyr, warn.conflicts = FALSE)
library(tidyr, warn.conflicts = FALSE)
library(purrr)
library(ggplot2)
library(Matrix, warn.conflicts = FALSE)
library(uwot)

assign_clusters_to_new_cohort_separate <- function(new_dat, validclusmod, cohort_name = "NewCohort") {
  
  
  IDCOL <- "eid"
  SEXVAR <- "sex"
  BODYSIZEINDEX <- "bmi"
  COVARIATES <- c("age", "smoking")
  BIOMARKERS <- c("sbp", "dbp", "scr", "hdl", "tg", "ldl", "fg")
  
  
  required_vars <- c(IDCOL, SEXVAR, BODYSIZEINDEX, COVARIATES, BIOMARKERS)
  missing_vars <- setdiff(required_vars, names(new_dat))
  if (length(missing_vars) > 0) {
    stop(paste("missing:", paste(missing_vars, collapse = ", ")))
  }
  
  
  new_strat_dat <- split(new_dat, new_dat[[SEXVAR]])
  
  
  results_list <- list()
  
  for (sex_gr in names(new_strat_dat)) {
    
    sex_data <- new_strat_dat[[sex_gr]]
    
    sex_model_idx <- which(validclusmod$sex == sex_gr)
    if (length(sex_model_idx) == 0) {
      warning(paste("There is no model for ", sex_gr))
      next
    }
    
    sex_model <- validclusmod[sex_model_idx, ]
    
    residmod <- sex_model$residmod[[1]]
    
    n_samples <- nrow(sex_data)
    resid_matrix <- matrix(NA, nrow = n_samples, ncol = length(BIOMARKERS))
    colnames(resid_matrix) <- BIOMARKERS
    
    for (i in seq_along(BIOMARKERS)) {
      biomarker <- BIOMARKERS[i]
      
      bm_params <- residmod[residmod$Biomarker == biomarker, ]
      
      X <- matrix(1, nrow = n_samples, ncol = 4)
      colnames(X) <- c("Intercept", "bmi", "age", "smoking")
      X[, "bmi"] <- sex_data$bmi
      X[, "age"] <- sex_data$age
      X[, "smoking"] <- sex_data$smoking
      
      coef_vector <- as.numeric(bm_params[1, c("Intercept", "bmi", "age", "smoking")])
      
      predicted <- as.vector(X %*% coef_vector)
      
      observed <- sex_data[[biomarker]]
      resid <- observed - predicted
      
      resid_sd <- bm_params$SDRes[1]
      
      std_resid <- resid / resid_sd
      resid_matrix[, i] <- std_resid
    }
    
    clusmod <- sex_model$clusmod[[1]]
    
    cluster_names <- clusmod$validclus_name
    
    cluster_weights <- clusmod$validclus_weights
    if (!is.null(names(cluster_weights))) {
      cluster_weights <- unname(cluster_weights)
    }
    
    cluster_centers <- clusmod$validclus_centers
    cluster_covmats <- clusmod$validclus_covmats
    
    n_clusters <- length(cluster_names)
    pdfs <- matrix(0, nrow = n_samples, ncol = n_clusters)
    
    for (i in 1:n_clusters) {
      mu <- cluster_centers[[i]][BIOMARKERS]
      covmat <- cluster_covmats[[i]][BIOMARKERS, BIOMARKERS]
      
      eigen_vals <- eigen(covmat)$values
      if (any(eigen_vals <= 0)) {
        covmat <- covmat + diag(abs(min(eigen_vals)) + 1e-6, nrow = nrow(covmat))
      }
      
      tryCatch({
        pdfs[, i] <- mvtnorm::dmvnorm(resid_matrix, mu, covmat, checkSymmetry = FALSE) * cluster_weights[i]
      }, error = function(e) {
        warning(paste("error for", cluster_names[i], ":", e$message))
        pdfs[, i] <- exp(-0.5 * rowSums((resid_matrix - matrix(mu, nrow = n_samples, ncol = length(mu), byrow = TRUE))^2)) * cluster_weights[i]
      })
    }
    
    row_sums <- rowSums(pdfs)
    zero_rows <- which(row_sums == 0)
    if (length(zero_rows) > 0) {
      warning(paste("sex", sex_gr, length(zero_rows)))
      pdfs[zero_rows, ] <- matrix(cluster_weights / sum(cluster_weights), 
                                  nrow = length(zero_rows), 
                                  ncol = n_clusters, 
                                  byrow = TRUE)
      row_sums[zero_rows] <- 1
    }
    
    cluster_probs <- pdfs / row_sums
    colnames(cluster_probs) <- cluster_names
    
    main_cluster_idx <- apply(cluster_probs, 1, which.max)
    main_cluster <- cluster_names[main_cluster_idx]
    main_prob <- apply(cluster_probs, 1, max)
    
    result_df <- data.frame(
      eid = sex_data$eid,
      sex = sex_gr,
      cohort = cohort_name,
      main_cluster = main_cluster,
      main_prob = round(main_prob, 4),
      as.data.frame(cluster_probs)
    )
    
    results_list[[sex_gr]] <- result_df
  
    print(table(result_df$main_cluster))
  }
  
  return(results_list)
}

load("../data/validclusmod.RData")

dat2 <- read.table("../data/Data_4C_3.8yr.txt",header = T,sep = "\t")

cluster_results <- assign_clusters_to_new_cohort_separate(
  new_dat = dat2,
  validclusmod = validclusmod,
  cohort_name = "4C_3.8yr"
)

all_columns <- unique(c(names(cluster_results$Female), names(cluster_results$Male)))

female_data <- cluster_results$Female
for(col in setdiff(all_columns, names(female_data))) {
  female_data[[col]] <- NA_real_  
}

male_data <- cluster_results$Male
for(col in setdiff(all_columns, names(male_data))) {
  male_data[[col]] <- NA_real_
}

#combined
combined_data <- bind_rows(female_data, male_data) %>%
  select(all_of(all_columns))

write.csv(combined_data, 
          "../data/4C_3.8yr_cluster_results.csv",
          row.names = FALSE)

##Merge the baseline and the 3.8-year clustering labels
data_base<- read.csv("../data/sample_cluster_4C.csv",row.names = 1)

result <- merge(combined_data, data_base, by = "eid") %>%
  mutate(base_cluster = gsub("prob", "", max_cluster)) %>%
  mutate(Group = paste(base_cluster, main_cluster, sep = "_"))

write.csv(result,"../data/4C_3yr with baseline.csv")

##Counting the number and proportion of clustering conversions
subdata_f <- subset(result, sex.x == "Female")
cluster_table_f <- table(subdata_f$max_cluster, subdata_f$main_cluster)
prop_table_f <- prop.table(cluster_table_f, margin = 1) 

df_count_f <- as.data.frame.matrix(cluster_table_f) %>%
  mutate(baseline = rownames(.), Type = "Number", sex = "Female", .before = 1)

df_ratio_f <- as.data.frame.matrix(round(prop_table_f, 3)) %>%
  mutate(baseline = rownames(.), Type = "Ratio", sex = "Female", .before = 1)

subdata_m <- subset(result, sex.x == "Male")
cluster_table_m <- table(subdata_m$max_cluster, subdata_m$main_cluster)
prop_table_m <- prop.table(cluster_table_m, margin = 1)

df_count_m <- as.data.frame.matrix(cluster_table_m) %>%
  mutate(baseline = rownames(.), Type = "Number", sex = "Male", .before = 1)

df_ratio_m <- as.data.frame.matrix(round(prop_table_m, 3)) %>%
  mutate(baseline = rownames(.), Type = "Ratio", sex = "Male", .before = 1)

combined <- bind_rows(df_count_f, df_ratio_f, df_count_m, df_ratio_m)


cluster_cols <- setdiff(colnames(combined), c("baseline", "Type", "sex"))
cluster_order <- c("HBP", "HFG", "HHDL", "HSCR", "HTG", "NSF")
cluster_cols_ordered <- intersect(cluster_order, cluster_cols)

combined <- combined[, c("baseline", cluster_cols_ordered, "sex", "Type")]

combined <- combined %>%
  arrange(sex, baseline, factor(Type, levels = c("Number", "Ratio")))

write.csv(combined, "../data/4C_3yr with baseline_count.csv",
          row.names = FALSE)
