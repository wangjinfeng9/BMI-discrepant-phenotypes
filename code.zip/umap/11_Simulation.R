# ================================
# 1. Load required packages
# ================================
library(dplyr)
library(tidyr)
library(purrr)
library(survival)
library(broom)
library(openxlsx)
library(doParallel)   # For parallel computing
library(foreach)

# ================================
# 2. Read data and preprocess (includes base_cluster)
# ================================
Data <- read.csv("../data/Data_4C.csv")#Including baseline and 3.8-year follow-up biomarkers, covariates,and CVD outcomes
data <- read.csv("../data/4C_3yr with baseline.csv")

Data <- Data %>%
  inner_join(data %>% dplyr::select(eid, base_cluster), by = "eid")#Merge baseline clustering labels

load("../data/validclusmod.RData")

# Define variable lists
biomarkers_base <- c("sbp", "dbp", "tg", "hdl", "ldl", "scr", "fg")
biomarkers_follow <- c("sbp_15", "dbp_15", "tg_15", "hdl_15", "ldl_15", "scr_15", "fg_15")
covariates_follow <- c("age_15", "bmi_15", "smoking_15")

# ================================
# 3. Compute correlation coefficients (by sex)
# ================================
correlations <- Data %>%
  group_by(sex) %>%
  summarise(
    r_sbp = cor(sbp, sbp_15, use = "complete.obs"),
    r_dbp = cor(dbp, dbp_15, use = "complete.obs"),
    r_tg  = cor(tg,  tg_15,  use = "complete.obs"),
    r_hdl = cor(hdl, hdl_15, use = "complete.obs"),
    r_ldl = cor(ldl, ldl_15, use = "complete.obs"),
    r_scr = cor(scr, scr_15, use = "complete.obs"),
    r_fg  = cor(fg,  fg_15,  use = "complete.obs")
  ) %>%
  pivot_longer(cols = starts_with("r_"), names_to = "biomarker", values_to = "r") %>%
  mutate(biomarker = gsub("r_", "", biomarker))

# ================================
# 4. Simulation function
# ================================
simulate_followup <- function(data, sex, correlations, seed_offset = 0) {
  set.seed(1 + seed_offset)  # Reproducibility
  sex_data <- data %>% filter(sex == !!sex)
  
  # Pre‑compute baseline mean and SD for each biomarker (by sex)
  stats <- sex_data %>%
    summarise(
      across(all_of(biomarkers_base), 
             list(mean = ~mean(.x, na.rm = TRUE), sd = ~sd(.x, na.rm = TRUE)), 
             .names = "{.col}_{.fn}")
    )
  
  simulated_follow <- map2_dfc(
    .x = biomarkers_base,
    .y = biomarkers_follow,   
    .f = function(b, f) {
      r <- correlations %>% filter(biomarker == b) %>% pull(r)
      if (is.na(r) || length(r) == 0) return(rep(NA_real_, nrow(sex_data)))
      
      mu <- stats[[paste0(b, "_mean")]]
      sigma <- stats[[paste0(b, "_sd")]]
      
      x <- sex_data[[b]]
      
      # Step 1: Impute true long‑term mean given baseline reading X1
      # Conditional mean = mu + r * (x - mu)
      # Conditional SD = sigma * sqrt(r * (1 - r))
      true_mean <- rnorm(nrow(sex_data), 
                         mean = mu + r * (x - mu), 
                         sd = sigma * sqrt(r * (1 - r)))
      
      # Step 2: Simulate second visit reading X2 from the true level
      # X2 = true_mean + error, error SD = sigma * sqrt(1 - r)
      sim <- rnorm(nrow(sex_data), 
                   mean = true_mean, 
                   sd = sigma * sqrt(1 - r))
      
      return(sim)
    }
  )
  names(simulated_follow) <- biomarkers_base
  
  sim_data <- sex_data %>%
    dplyr::select(eid, sex) %>%
    mutate(
      age = sex_data[[covariates_follow[1]]],
      bmi = sex_data[[covariates_follow[2]]],
      smoking = sex_data[[covariates_follow[3]]]
    ) %>%
    bind_cols(simulated_follow)
  return(sim_data)
}

# ================================
# 5. Cluster assignment function (using pre‑trained validclusmod)
# ================================
assign_clusters_to_new_cohort_separate <- function(new_dat, validclusmod, cohort_name = "NewCohort") {
  
  IDCOL <- "eid"
  SEXVAR <- "sex"
  BODYSIZEINDEX <- "bmi"
  COVARIATES <- c("age", "smoking")
  BIOMARKERS <- c("sbp", "dbp", "scr", "hdl", "tg", "ldl", "fg")
  
  # Check required variables
  required_vars <- c(IDCOL, SEXVAR, BODYSIZEINDEX, COVARIATES, BIOMARKERS)
  missing_vars <- setdiff(required_vars, names(new_dat))
  if (length(missing_vars) > 0) {
    stop(paste("New data missing variables:", paste(missing_vars, collapse = ", ")))
  }
  
  # Split by sex
  new_strat_dat <- split(new_dat, new_dat[[SEXVAR]])
  results_list <- list()
  
  for (sex_gr in names(new_strat_dat)) {
    cat("Processing sex:", sex_gr, "\n")
    
    sex_data <- new_strat_dat[[sex_gr]]
    
    sex_model_idx <- which(validclusmod$sex == sex_gr)
    if (length(sex_model_idx) == 0) {
      warning(paste("No model found for sex", sex_gr))
      next
    }
    
    sex_model <- validclusmod[sex_model_idx, ]
    residmod <- sex_model$residmod[[1]]
    
    n_samples <- nrow(sex_data)
    resid_matrix <- matrix(NA, nrow = n_samples, ncol = length(BIOMARKERS))
    colnames(resid_matrix) <- BIOMARKERS
    
    # Compute standardized residuals for each biomarker
    for (i in seq_along(BIOMARKERS)) {
      biomarker <- BIOMARKERS[i]
      bm_params <- residmod[residmod$Biomarker == biomarker, ]
      
      if (nrow(bm_params) != 1) {
        warning(paste("Incorrect parameter count for biomarker", biomarker))
        next
      }
      
      # Design matrix
      X <- matrix(1, nrow = n_samples, ncol = 4)
      colnames(X) <- c("Intercept", "bmi", "age", "smoking")
      X[, "bmi"] <- sex_data$bmi
      X[, "age"] <- sex_data$age
      X[, "smoking"] <- sex_data$smoking
      
      coef_vector <- as.numeric(bm_params[1, c("Intercept", "bmi", "age", "smoking")])
      predicted <- as.vector(X %*% coef_vector)
      observed <- sex_data[[biomarker]]
      resid <- observed - predicted
      
      resid_sd <- bm_params$SDRes[1]
      if (is.na(resid_sd) || resid_sd == 0) {
        warning(paste("Invalid residual SD for biomarker", biomarker))
        resid_sd <- 1
      }
      std_resid <- resid / resid_sd
      resid_matrix[, i] <- std_resid
    }
    
    # Extract clustering model parameters
    clusmod <- sex_model$clusmod[[1]]
    cluster_names <- clusmod$validclus_name
    cluster_weights <- clusmod$validclus_weights
    if (!is.null(names(cluster_weights))) {
      cluster_weights <- unname(cluster_weights)
    }
    cluster_centers <- clusmod$validclus_centers
    cluster_covmats <- clusmod$validclus_covmats
    
    # Compute Gaussian densities for each cluster
    n_clusters <- length(cluster_names)
    pdfs <- matrix(0, nrow = n_samples, ncol = n_clusters)
    
    for (i in 1:n_clusters) {
      mu <- cluster_centers[[i]][BIOMARKERS]
      covmat <- cluster_covmats[[i]][BIOMARKERS, BIOMARKERS]
      
      # Ensure positive definite
      eigen_vals <- eigen(covmat)$values
      if (any(eigen_vals <= 0)) {
        covmat <- covmat + diag(abs(min(eigen_vals)) + 1e-6, nrow = nrow(covmat))
      }
      
      tryCatch({
        pdfs[, i] <- mvtnorm::dmvnorm(resid_matrix, mu, covmat, checkSymmetry = FALSE) * cluster_weights[i]
      }, error = function(e) {
        warning(paste("Error computing density for cluster", cluster_names[i], ":", e$message))
        # Fallback approximation
        pdfs[, i] <- exp(-0.5 * rowSums((resid_matrix - matrix(mu, nrow = n_samples, ncol = length(mu), byrow = TRUE))^2)) * cluster_weights[i]
      })
    }
    
    # Calculate cluster probabilities
    row_sums <- rowSums(pdfs)
    zero_rows <- which(row_sums == 0)
    if (length(zero_rows) > 0) {
      warning(paste("Sex", sex_gr, "has", length(zero_rows), "rows with zero density; assigning equal probabilities"))
      pdfs[zero_rows, ] <- matrix(cluster_weights / sum(cluster_weights), 
                                  nrow = length(zero_rows), 
                                  ncol = n_clusters, 
                                  byrow = TRUE)
      row_sums[zero_rows] <- 1
    }
    
    cluster_probs <- pdfs / row_sums
    colnames(cluster_probs) <- cluster_names
    
    # Determine main cluster
    main_cluster_idx <- apply(cluster_probs, 1, which.max)
    main_cluster <- cluster_names[main_cluster_idx]
    main_prob <- apply(cluster_probs, 1, max)
    
    result_df <- data.frame(
      eid = sex_data$eid,
      sex = sex_gr,
      cohort = cohort_name,
      main_cluster = main_cluster,
      main_prob = round(main_prob, 4),
      as.data.frame(cluster_probs)
    )
    
    results_list[[sex_gr]] <- result_df
    
    cat("  Sex", sex_gr, "completed\n")
    cat("  Samples:", n_samples, "\n")
    cat("  Cluster distribution:\n")
    print(table(result_df$main_cluster))
  }
  
  return(results_list)
}

# ================================
# 6. Cox analysis function (returns only model 2)
# ================================
get_cox_model2 <- function(data_combined, ref_group, comp_group, outcome) {
  ref_data <- data_combined %>% filter(Group == ref_group)
  comp_data <- data_combined %>% filter(Group == comp_group)
  if (nrow(ref_data) < 10 | nrow(comp_data) < 10) return(NULL)
  
  analysis_data <- bind_rows(ref_data %>% mutate(group = 0),
                             comp_data %>% mutate(group = 1))
  
  # Determine time/event columns based on outcome
  if (outcome == "CVD") {
    time_var <- "timecvd21"; event_var <- "CVD"
  } else if (outcome == "MI") {
    time_var <- "timemi21"; event_var <- "MI"
  } else if (outcome == "Stroke") {
    time_var <- "timestroke21"; event_var <- "Stroke"
  } else stop("Invalid outcome")
  
  if (sum(analysis_data[[event_var]]) < 5) return(NULL)
  
  formula2 <- as.formula(paste("Surv(", time_var, ", ", event_var, 
                               ") ~ group + smoking + age + bmi + sbp + dbp + hdl + fg + scr + ldl + tg"))
  model <- tryCatch(coxph(formula2, data = analysis_data), error = function(e) NULL)
  if (is.null(model)) return(NULL)
  
  sum_model <- summary(model)
  group_coef <- sum_model$coefficients["group", ]
  conf_int <- sum_model$conf.int["group", ]
  
  data.frame(
    ref_group = ref_group,
    comp_group = comp_group,
    outcome = outcome,
    hr = conf_int[1],
    hr_lower = conf_int[3],
    hr_upper = conf_int[4],
    p_value = group_coef[5],
    stringsAsFactors = FALSE
  )
}

# ================================
# 7. Helper to get comparison groups
# ================================
get_comparison_groups <- function(ref_group, all_groups) {
  if (ref_group == "NSF_NSF") {
    return(all_groups[grepl("^NSF_", all_groups) & all_groups != "NSF_NSF"])
  } else {
    prefix <- sub("_.*", "", ref_group)
    return(all_groups[grepl(paste0("^", prefix, "_"), all_groups) & all_groups != ref_group])
  }
}

# ================================
# 8. Prepare baseline data (after exclusion)
# ================================
baseline_data <- Data %>%
  dplyr::select(eid, sex, age, bmi, smoking, base_cluster, all_of(biomarkers_base), 
                all_of(covariates_follow), CVD, timecvd21, MI, timemi21, Stroke, timestroke21,
                antihypertensive, lipidlower_drug, cvd15) %>%
  filter(antihypertensive != 1 & lipidlower_drug != 1) %>%
  filter(cvd15 == 0)

# ================================
# 9. Extract baseline cluster assignment (fixed)
# ================================
base_cluster_mapping <- baseline_data %>%
  dplyr::select(eid, sex, baseline_cluster = base_cluster)

# ================================
# 10. Parallel simulation (1000 iterations)
# ================================
n_iter <- 1000
sexes <- c("Male", "Female")
outcomes <- c("CVD", "MI", "Stroke")

cl <- makeCluster(detectCores() - 2)
registerDoParallel(cl)

results_all <- foreach(sex = sexes,
                       .packages = c("dplyr", "tidyr", "survival", "mvtnorm",
                                     "purrr", "stringr", "broom"),
                       .combine = rbind) %dopar% {
                         
                         sex_clean <- baseline_data %>% filter(sex == !!sex)
                         sex_mapping <- base_cluster_mapping %>% filter(sex == !!sex)
                         sex_cor <- correlations %>% filter(sex == !!sex)
                         
                         iter_results <- list()
                         
                         for (iter in 1:n_iter) {
                           sim_follow <- simulate_followup(Data, sex, sex_cor, seed_offset = iter * 100 + which(sexes == sex))
                           sim_follow_clean <- sim_follow %>% na.omit()
                           
                           follow_cluster <- assign_clusters_to_new_cohort_separate(
                             new_dat = sim_follow_clean,
                             validclusmod = validclusmod,
                             cohort_name = "Followup"
                           )[[sex]]
                           
                           combined <- sex_mapping %>%
                             inner_join(follow_cluster %>% dplyr::select(eid, follow_cluster = main_cluster), by = "eid") %>%
                             mutate(Group = paste(baseline_cluster, follow_cluster, sep = "_"))
                           
                           cox_data_full <- sex_clean %>%
                             dplyr::select(eid, CVD, timecvd21, MI, timemi21, Stroke, timestroke21,
                                           smoking, age, bmi, sbp, dbp, hdl, fg, scr, ldl, tg) %>%
                             inner_join(combined, by = "eid")
                           
                           for (outcome in outcomes) {
                             if (outcome == "CVD") {
                               time_var <- "timecvd21"; event_var <- "CVD"
                             } else if (outcome == "MI") {
                               time_var <- "timemi21"; event_var <- "MI"
                             } else if (outcome == "Stroke") {
                               time_var <- "timestroke21"; event_var <- "Stroke"
                             }
                             
                             cox_data <- cox_data_full %>%
                               dplyr::select(eid, Group, !!event_var, !!time_var,
                                             smoking, age, bmi, sbp, dbp, hdl, fg, scr, ldl, tg) %>%
                               filter(complete.cases(.))
                             
                             if (nrow(cox_data) == 0) next
                             
                             all_groups <- unique(cox_data$Group)
                             ref_groups <- c("NSF_NSF", all_groups[grepl("^(\\w+)_\\1$", all_groups) & all_groups != "NSF_NSF"])
                             ref_groups <- unique(ref_groups)
                             
                             for (ref in ref_groups) {
                               comps <- get_comparison_groups(ref, all_groups)
                               if (length(comps) == 0) next
                               for (comp in comps) {
                                 res <- get_cox_model2(cox_data, ref, comp, outcome)
                                 if (!is.null(res)) {
                                   res$sex <- sex
                                   res$iteration <- iter
                                   iter_results[[length(iter_results) + 1]] <- res
                                 }
                               }
                             }
                           }
                           
                           message(paste0(Sys.time(), "  Sex: ", sex, ", Iteration: ", iter, " completed"))
                         }
                         
                         bind_rows(iter_results)
                       }

stopCluster(cl)

# ================================
# 11. Summarise results and export Excel
# ================================
summary_stats <- results_all %>%
  group_by(sex, ref_group, comp_group, outcome) %>%
  summarise(
    n_iter = n(),
    hr_mean = mean(hr, na.rm = TRUE),
    hr_median = median(hr, na.rm = TRUE),
    hr_lower_2.5 = quantile(hr, 0.025, na.rm = TRUE),
    hr_upper_97.5 = quantile(hr, 0.975, na.rm = TRUE),
    p_less_0.05 = mean(p_value < 0.05, na.rm = TRUE) * 100,
    .groups = "drop"
  ) %>%
  mutate(HR_95CI = sprintf("%.2f (%.2f-%.2f)", hr_mean, hr_lower_2.5, hr_upper_97.5))

wb <- createWorkbook()
for (sex in sexes) {
  sex_sheet <- summary_stats %>% filter(sex == !!sex)
  addWorksheet(wb, sheetName = sex)
  writeData(wb, sex, sex_sheet)
  setColWidths(wb, sex, cols = 1:ncol(sex_sheet), widths = "auto")
}

output_file <- "../data/Simulation_Cox_Results_1000iter.xlsx"
saveWorkbook(wb, output_file, overwrite = TRUE)
cat("\nAnalysis complete! Results saved to", output_file, "\n")

write.csv(results_all, "../data/Simulation_Cox_Results_1000iter.csv")

# ================================
# 12. Compare simulated HR with observed real HR
# ================================
HRData <- read.csv("../data/Cox result.csv")#real HR

sim_hr_nested <- results_all %>%
  group_by(sex, ref_group, comp_group, outcome) %>%
  summarise(sim_hr = list(hr), .groups = "drop")

comparison_table_p <- HRData %>%
  inner_join(sim_hr_nested, by = c("sex", "ref_group", "comp_group", "outcome")) %>%
  rowwise() %>%
  mutate(
    p_sim = {
      vec <- sim_hr
      obs <- hr
      if (length(vec) < 10) {
        NA_real_
      } else {
        if (ref_group == "NSF_NSF") {
          mean(vec >= obs, na.rm = TRUE)
        } else {
          mean(vec <= obs, na.rm = TRUE)
        }
      }
    }
  ) %>%
  ungroup() %>%
  dplyr::select(-sim_hr)

write.csv(comparison_table_p, "../data/1000comparison_table_p.csv")