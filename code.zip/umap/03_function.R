## Functions to assess predictive ability of clusters

## Columns needed
BIOMARKERS <- c("sbp", "dbp", "scr", "hdl", "tg", "ldl", "fg")
BODYSIZEINDEX <- "bmi"
COVARIATES <- c("age", "smoking")
DISEASES <- c("HTN", "stroke", "ckd", "mi", "cvd", "dm")
MEDICATION <- c("antihypertensive",	"lipidlower_drug")

# Calculating cluster probabilities
clusterprobcalc <- function(ClusModDf, StratDat){
  alldat <- dplyr::mutate(ClusModDf, data = purrr::map(sex, ~StratDat[[.x]]))
  dplyr::transmute(
    alldat,
    sex,
    # Calculate standardized residuals
    resids = purrr::map2(
      data, residmod,
      function(DATA, RESIDMOD){
        sapply(
          BIOMARKERS,
          function(biomarker){
            PREDICTDAT <- as.matrix(cbind(Intercept = 1, DATA[,c(BODYSIZEINDEX, COVARIATES)]))
            MODELDAT <- dplyr::filter(RESIDMOD, Biomarker == biomarker)
            RESIDSD <- MODELDAT$SDRes
            COEFDAT <- MODELDAT[,c("Intercept", BODYSIZEINDEX, COVARIATES)]
            COEFDAT <- t(COEFDAT)
            PREDVAL <- as.vector(PREDICTDAT %*% COEFDAT)
            RESIDVAL <- DATA[[biomarker]] - PREDVAL
            RESIDVAL / RESIDSD
          }
        )
      }
    ),
    # Calculate probabilities to valid clusters
    probs = purrr::map2(
      resids, clusmod,
      function(RESIDDF, CLUSMOD){
        mus <- CLUSMOD$validclus_centers
        mus <- purrr::map(mus, function(mu){ mu[BIOMARKERS] })
        covmats <- CLUSMOD$validclus_covmats
        covmats <- purrr::map(covmats, function(covmat){ covmat[BIOMARKERS, BIOMARKERS] })
        wts <- CLUSMOD$validclus_weights
        pdfs <- mapply(function(mu, covmat){ mvtnorm::dmvnorm(RESIDDF, mu, covmat) }, mus, covmats)
        L <- pdfs %*% diag(wts)
        colnames(L) <- paste0("prob", CLUSMOD$validclus_name)
        data.frame(L / rowSums(L))
      }
    ),
    data = purrr::map2(data, probs, bind_cols),
    resids = NULL, probs = NULL
  )
}

# Variable types
vartype <- function(x){
  if(is.numeric(x)){
    if(length(unique(x)) > 10){
      return("Numeric")
    } else { 
      return("Categorical")
    }
  } else {
    if(is.character(x) | is.factor(x)){
      return("Categorical")
    } else {
      return(NA)
    }
  }
}

# Weighted mean
wtd_mean <- function(x, p){
  sum(x*p)/sum(p)
}

# Weighted variance
wtd_var <- function(x, p){
  xhat <- wtd_mean(x, p)
  sum(((x - xhat)^2)*p)/sum(p)
}

# Weighted quantiles
# Taken from: https://aakinshin.net/posts/weighted-quantiles/
wtd_quantile <- function(x, p, q){
  n <- sum(p)
  indexes <- order(x)
  x <- x[indexes]
  p <- p[indexes]
  p <- p / n
  cdfprobs <- cumsum(c(0, p))
  sapply(
    setNames(q, q), 
    function(QUANTILE) {
      Q <- pbeta(cdfprobs, n * QUANTILE, n * (1 - QUANTILE))
      W <- tail(Q, -1) - head(Q, -1)
      sum(W * x)
    }
  )
}

# Weighted proportions
wtd_table <- function(x, p){
  LEVELS <- unique(x)
  sapply(
    setNames(LEVELS, LEVELS),
    function(LEVEL){
      sum((x == LEVEL) * p)
    }
  )
}

# Weighted summary of categorical variables
wtd_categorical_sumstats <- function(x, p){
  vals <- wtd_table(x, p)
  vals <- sort(vals, decreasing = TRUE)
  tibble::tibble(
    N = sum(p),
    Summary1 = names(vals), 
    Summary2 = as.character(round(vals, 2))
  )
}

# Weighted summary of continuous variables
wtd_continuous_sumstats <- function(x, p){
  Mn <- round(wtd_mean(x, p), 2)
  Sd <- round(sqrt(wtd_var(x, p)), 2)
  quants <- wtd_quantile(x, p, q = c(.025, .25, .5, .75, .975))
  Md <- round(quants[3], 2)
  pc <- round(quants[-3], 2)
  pc <- paste(pc, collapse = " - ")
  tibble::tibble(
    N = sum(p),
    Summary1 = paste0(Mn, " (", Sd, ")"),
    Summary2 = paste0(Md, " (", pc, ")")
  )
}

# Weighted summary of a variable
wtd_sumstatfx <- function(x, p){
  vartyp <- vartype(x)
  xres <- switch(
    vartyp,
    Categorical = wtd_categorical_sumstats(x, p),
    Numeric = wtd_continuous_sumstats(x, p),
    stop("A column is not in the right format")
  )
  data.frame(Type = vartyp, xres)
}

# Weighted summary of all variables
markerdistribfx <- function(X){
  RES <- dplyr::transmute(
    X,
    sex,
    RES1 = purrr::map(
      data,
      ~{
        RES2 <- tidyr::expand_grid(
          Variable = c(BIOMARKERS, COVARIATES, BODYSIZEINDEX),
          Cluster = names(.x)[grepl("^prob", names(.x))]
        )
        RES2 <- dplyr::mutate(
          RES2,
          RES3 = purrr::map2(
            Variable, Cluster,
            function(COL, PROB, DAT){
              wtd_sumstatfx(DAT[[COL]], DAT[[PROB]])
            },
            DAT = .x
          )
        )
        tidyr::unnest(RES2, RES3)
      }
    )
  )
  RES <- tidyr::unnest(RES, RES1)
  dplyr::mutate(RES, Cluster = gsub("prob", "", Cluster))
}

# BMI effect on biomarkers specific to each cluster
bmieffmarkerfx <- function(X){
  RES <- dplyr::transmute(
    X,
    sex,
    RES1 = purrr::map(
      data,
      ~{
        RES2 <- tidyr::expand_grid(
          Variable = BIOMARKERS,
          Cluster = names(.x)[grepl("^prob", names(.x))]
        )
        RES2 <- dplyr::mutate(
          RES2,
          RES3 = purrr::map2(
            Variable, Cluster,
            function(COL, PROB, DAT, COVARS){
              D <- dplyr::select(DAT, all_of(c(COL, COVARS)))
              mod <- lm(reformulate(response = COL, termlabels = "."),
                        data = D, weights = DAT[[PROB]])
              modcoefs <- coef(summary(mod))
              modcoefs <- data.frame(term = rownames(modcoefs), modcoefs)
              modcoefs <- dplyr::select(
                modcoefs,
                term, estimate = Estimate, se = Std..Error
              )
              return(modcoefs)
            },
            DAT = .x, COVARS = c(COVARIATES, BODYSIZEINDEX)
          )
        )
        tidyr::unnest(RES2, RES3)
      }
    )
  )
  RES <- tidyr::unnest(RES, RES1)
  dplyr::mutate(RES, Cluster = gsub("prob", "", Cluster))
}

# Adding covariate data
addcovardat <- function(X, CovarDat){
  dplyr::mutate(
    X,
    data = purrr::map(data, inner_join, CovarDat, by = "eid")
  )
}

# Counts of individuals with diseases/medication per cluster
countcovarsfx <- function(X){
  RES <- dplyr::transmute(
    X,
    sex,
    countres = purrr::map(
      data,
      function(DAT){
        clusnams <- names(DAT)[grepl("^prob", names(DAT))]
        DXandMed <- c(DISEASES, MEDICATION)
        RES1 <- tidyr::expand_grid(
          Cluster = clusnams,
          Covariate = DXandMed
        )
        dplyr::mutate(
          RES1,
          Nclus = purrr::map2_dbl(
            Cluster, Covariate,
            function(CL, CO, D){
              valid_cases <- !is.na(D[[CO]])
              sum(D[[CL]][valid_cases], na.rm = TRUE)
            },
            D = DAT
          ),
          Ncases = purrr::map2_dbl(
            Cluster, Covariate,
            function(CL, CO, D){
              valid_cases <- !is.na(D[[CO]])
              sum(D[[CO]][valid_cases] * D[[CL]][valid_cases], na.rm = TRUE)
            },
            D = DAT
          ),
          Nnoncases = Nclus - Ncases
        )
      }
    )
  )
  tidyr::unnest(RES, countres)
}

# Counts of individuals with specific diseases and medication combinations per cluster
countdxmedfx <- function(X){
  RES <- dplyr::mutate(
    X,
    data = purrr::map(
      data,
      ~{
        RES1 <- tidyr::pivot_longer(.x, dplyr::starts_with("prob"), names_to = "Cluster", values_to = "prob")
        RES1 <- tidyr::pivot_longer(RES1, dplyr::all_of(DISEASES), names_to = "Dx", values_to = "Dx_value")
        RES1 <- dplyr::group_by(RES1, Dx, Dx_value, Cluster)
        RES1 <- dplyr::summarise(
          RES1,
          NoMed = sum((rowSums(dplyr::pick(dplyr::all_of(MEDICATION))) == 0) * prob),
          dplyr::across(dplyr::all_of(MEDICATION), \(x) round(sum(x * prob))),
          .groups = "drop"
        )
        RES1 <- tidyr::pivot_longer(RES1, c(NoMed, dplyr::all_of(MEDICATION)), names_to = "Med", values_to = "Med_value")
        RES1 <- dplyr::mutate(RES1, Dx_value = dplyr::case_match(Dx_value, 1 ~ "Ncases", 0 ~ "Nnoncases"))
        tidyr::pivot_wider(RES1, names_from = Dx_value, values_from = Med_value)
      }
    )
  )       
  tidyr::unnest(RES, data)
}

# Logistic regressions with cluster probabilities against current diseases
assocdxfx <- function(X){
  RES <- dplyr::mutate(
    X,
    data = purrr::map(
      data,
      function(DAT){
        DAT <- tidyr::pivot_longer(
          DAT,
          dplyr::all_of(DISEASES),
          names_to = "Dx_name",
          values_to = "Dx_value"
        )
        DAT <- tidyr::nest(DAT, DxDat = -Dx_name)
        #DAT <- dplyr::filter(DAT, purrr::map_dbl(DxDat, \(x) sum(x$Dx_value)) > 5)
        DAT <- dplyr::mutate(
          DAT,
          DxDat = purrr::map(
            DxDat,
            function(DXD){
              DXD <- dplyr::transmute(
                DXD,
                Dx_value,
                dplyr::across(dplyr::starts_with("prob"), \(x) ifelse(x < 1e-15, 1e-15, x)),
                dplyr::across(dplyr::starts_with("prob"), \(x) ifelse(x > (1 - 1e-15), (1 - 1e-15), x)),
                dplyr::across(dplyr::starts_with("prob"), \(x) log(x/probNSF), .names = "alr{.col}"),
                alrprobNSF = NULL,
                dplyr::across(dplyr::starts_with("prob"), \(P) NULL),
                dplyr::across(dplyr::all_of(c(BODYSIZEINDEX, COVARIATES, BIOMARKERS, MEDICATION)))
              )
              D1 <- dplyr::select(DXD, Dx_value, dplyr::starts_with("alr"))
              MOD1 <- glm(Dx_value ~ ., family = binomial, data = D1)
              RES1 <- tibble::tibble(
                model = "OnlyClusters",
                estimates = list(coef(MOD1)),
                varcovmat = list(vcov(MOD1))
              )
              MOD2 <- glm(Dx_value ~ ., family = binomial, data = DXD)
              RES2 <- tibble::tibble(
                model = "FullModel",
                estimates = list(coef(MOD2)),
                varcovmat = list(vcov(MOD2))
              )
              bind_rows(RES1, RES2)
            }
          )
        )
        tidyr::unnest(DAT, DxDat)
      }
    )
  )
  tidyr::unnest(RES, data)
}

# Adding survival data
addsurvdat <- function(X, SurvMACEDf, SurvMIDf, SurvSTDf){
  X1 <- dplyr::transmute(
    X, sex, outcome = "CVD",
    data = purrr::map(data, dplyr::inner_join, SurvMACEDf, by = "eid"),
    data = purrr::map(data, filter, !is.na(outcome_value))
  )
  X2 <- dplyr::transmute(
    X, sex, outcome = "MI",
    data = purrr::map(data, dplyr::inner_join, SurvMIDf, by = "eid"),
    data = purrr::map(data, filter, !is.na(outcome_value))
  )
  X3 <- dplyr::transmute(
    X, sex, outcome = "Stroke",
    data = purrr::map(data, dplyr::inner_join, SurvSTDf, by = "eid"),
    data = purrr::map(data, filter, !is.na(outcome_value))
  )
  RES <- dplyr::bind_rows(X1, X2, X3)
  dplyr::mutate(
    RES,
    data = purrr::map(data, dplyr::select, -dplyr::where(\(x) all(x == 0 ,na.rm = T)))
  )
}

# Follow-up subsets
futsubsetsfx <- function(X){
  RES <- tidyr::expand_grid(
    X,
    fut = c(5, 10)
  )
  RES <- dplyr::mutate(
    RES,
    data = purrr::map2(
      data, fut,
      function(DAT, FUT){
        dplyr::mutate(
          DAT,
          outcome_value = outcome_value * (outcome_timeyrs <= FUT),
          outcome_timeyrs = pmin(outcome_timeyrs, FUT)
        )
      }
    ),
    maxfut = map_dbl(data, ~max(.x$outcome_timeyrs)),
    valid = T 
  )
  RES <- dplyr::filter(RES, valid)
  dplyr::select(RES, -c(valid, maxfut))
}

# Summary function
survsumfx <- function(X){
  RES <- dplyr::transmute(
    X,
    sex, outcome, fut,
    data = purrr::map(
      data,
      function(DAT){
        data.frame(
          N = nrow(DAT),
          Ncases = sum(DAT$outcome_value, na.rm = TRUE),
          TPT = sum(DAT$outcome_timeyrs, na.rm = TRUE),
          t(setNames(quantile(DAT$outcome_timeyrs, 
                              probs = c(.025, .25, .5, .75, .975)),
                     paste0("timeq", c(2.5, 25, 50, 75, 97.5))))
        )
      }
    )
  )
  unnest(RES, data)
}

# Rates of outcome by cluster
ratesclusfx <- function(X){
  RES <- dplyr::mutate(
    X,
    data = purrr::map(
      data,
      function(DAT){
        prob_cols <- grep("^prob", names(DAT), value = TRUE)
        DAT$hard_cluster <- prob_cols[apply(DAT[, prob_cols, drop = FALSE], 1, which.max)]
        
        # Probability weighted
        dat_long <- tidyr::pivot_longer(
          DAT,
          dplyr::all_of(prob_cols),
          names_to = "Cluster",
          values_to = "prob"
        )
        weighted <- dplyr::group_by(dat_long, Cluster) %>%
          dplyr::summarise(
            N_total = sum(prob, na.rm = TRUE),
            Ncases = sum(outcome_value * prob, na.rm = TRUE),
            Nnoncases = sum((1 - outcome_value) * prob, na.rm = TRUE),
            TPT = sum(outcome_timeyrs * prob, na.rm = TRUE),
            .groups = "drop"
          )
        
        # Hard classification
        hard <- DAT %>%
          dplyr::group_by(hard_cluster) %>%
          dplyr::summarise(
            hard_Ncases = sum(outcome_value == 1, na.rm = TRUE),
            hard_Nnoncases = sum(outcome_value == 0, na.rm = TRUE),
            hard_TPT = sum(outcome_timeyrs, na.rm = TRUE),
            .groups = "drop"
          ) %>%
          dplyr::rename(Cluster = hard_cluster)
        
        dplyr::left_join(weighted, hard, by = "Cluster")
      }
    )
  )
  tidyr::unnest(RES, data)
}

# Rates of outcome by cluster and medication
ratesclusmedfx <- function(X){
  RES <- dplyr::mutate(
    X,
    data = purrr::map(
      data,
      function(DAT){
        DAT <- dplyr::mutate(
          DAT, 
          NoMed = 1 * (rowSums(dplyr::pick(dplyr::any_of(MEDICATION))) == 0)
        )
        DAT <- tidyr::pivot_longer(
          DAT,
          dplyr::starts_with("prob"),
          names_to = "Cluster",
          values_to = "prob"
        )
        DAT <- tidyr::pivot_longer(
          DAT,
          c(NoMed, dplyr::any_of(MEDICATION)),
          names_to = "Med_name",
          values_to = "Med_value"
        )
        DAT <- dplyr::group_by(DAT, Cluster, Med_name)
        dplyr::summarise(
          DAT,
          Ncases = sum(Med_value * outcome_value * prob),
          TPT = sum(Med_value * outcome_timeyrs * prob),
          .groups = "drop"
        )
      }
    )
  )
  tidyr::unnest(RES, data)
}

# Running Cox models
coxmodels <- function(X){
  X1 <- dplyr::filter(X, outcome == "CVD")
  X1 <- dplyr::mutate(
    X1,
    survdf = purrr::map2(
      data, sex,
      function(DATA, SEX){
        MODELDAT <- dplyr::transmute(
          DATA,
          eid,
          outcome_value,
          outcome_timeyrs,
          age,bmi,
          smoking,
          sbp,dbp,
          hdl,ldl,tg,
          fg,
          scr, 
          dplyr::across(dplyr::starts_with("prob"))
        )
      }
    )
  )
  X2 <- dplyr::filter(X, outcome == "MI")
  X2 <- dplyr::mutate(
    X2,
    survdf = purrr::map2(
      data, sex,
      function(DATA, SEX){
        MODELDAT <- dplyr::transmute(
          DATA,
          eid,
          outcome_value,
          outcome_timeyrs,
          age,bmi,
          smoking,
          sbp,dbp,
          hdl,ldl,tg,
          fg,
          scr,
          dplyr::across(dplyr::starts_with("prob"))
        )
      }
    )
  )
  X3 <- dplyr::filter(X, outcome == "Stroke")
  X3 <- dplyr::mutate(
    X3,
    survdf = purrr::map2(
      data, sex,
      function(DATA, SEX){
        MODELDAT <- dplyr::transmute(
          DATA,
          eid,
          outcome_value,
          outcome_timeyrs,
          age,bmi,
          smoking,
          sbp,dbp,
          hdl,ldl,tg,
          fg,
          scr,
          dplyr::across(dplyr::starts_with("prob"))
        )
      }
    )
  )
  NewX <- dplyr::bind_rows(X1, X2, X3)
  dplyr::mutate(
    NewX,
    survdf = purrr::map(
      survdf, 
      function(DATA){
        DATA <- dplyr::mutate(
          DATA,
          dplyr::across(
            dplyr::everything(),
            function(x){ 
              x[is.infinite(x)] <- NaN
              return(x)
            }
          )
        )
        DATA[complete.cases(DATA),]
      }
    ),
    data = purrr::map2(
      data, survdf,
      function(D1, D2){
        ID <- dplyr::select(D2, eid)
        dplyr::inner_join(ID, D1, by = "eid")
      }
    ),
    survdf = purrr::map(survdf, dplyr::select, -eid),
    survdf = purrr::map(
      survdf,
      function(DATA){
        dplyr::mutate(
          DATA,
          dplyr::across(dplyr::starts_with("prob"), \(x) ifelse(x < 1e-15, 1e-15, x)),
          dplyr::across(dplyr::starts_with("prob"), \(x) ifelse(x > (1 - 1e-15), (1 - 1e-15), x)),
          dplyr::across(dplyr::starts_with("prob"), \(P) log(P/probNSF), .names = "alr{.col}"),
          alrprobNSF = NULL,
          dplyr::across(dplyr::starts_with("prob"), \(P) NULL)
        )
      }
    ),
    NullMod = purrr::map(
      survdf, 
      ~survival::coxph(
        survival::Surv(time = outcome_timeyrs, event = outcome_value) ~ 1, 
        data = .x
      )
    ),
    mod_base = purrr::map(
      survdf,
      ~{
        MODELDAT <- dplyr::select(.x, -dplyr::starts_with("alrprob"))
        MOD1 <- survival::coxph(survival::Surv(time = outcome_timeyrs, event = outcome_value) ~ ., data = MODELDAT)
        COEFS <- coef(MOD1)
        COEFSNA <- COEFS[is.na(COEFS)]
        MODELDAT <- dplyr::select(MODELDAT, -all_of(names(COEFSNA)))
        survival::coxph(survival::Surv(time = outcome_timeyrs, event = outcome_value) ~ ., data = MODELDAT)
      }
    ),
    mod_clus = purrr::map(
      survdf,
      ~{
        MOD1 <- survival::coxph(survival::Surv(time = outcome_timeyrs, event = outcome_value) ~ ., data = .x)
        COEFS <- coef(MOD1)
        COEFSNA <- COEFS[is.na(COEFS)]
        MODELDAT <- dplyr::select(.x, -all_of(names(COEFSNA)))
        survival::coxph(survival::Surv(time = outcome_timeyrs, event = outcome_value) ~ ., data = MODELDAT)
      }
    )
  )
}

# Obtain cumulative hazard/survival probabilities with summary data generated
PredCumHaz <- function(AFit, Means, Coefs, VCoVMat, NewX){
  newx <- dplyr::select(NewX, -outcome_time)
  newx <- as.matrix(newx)
  newtime <- NewX$outcome_time
  newx <- newx - rep(Means, each = nrow(newx))
  newrisk <- c(exp(newx %*% Coefs))
  j1 <- approx(
    x = AFit$time, y = 1:length(AFit$time), xout = newtime, 
    method = "constant", f = 0, yleft = 0, yright = length(AFit$time)
  )
  j1 <- j1$y
  chaz <-c(0, AFit$cumhaz)[j1+1]
  pred <- chaz * newrisk
  varh <- c(0, cumsum(AFit$varhaz))[j1+1]
  xbar <- rbind(0, AFit$xbar)[j1+1,,drop=F]
  dt <- (chaz * newx) - xbar
  se <- sqrt(varh + rowSums((dt %*% VCoVMat) *dt)) * newrisk
  tibble(fit = drop(pred), se.fit = drop(se))
  # To convert to survival: 
  # pred <- exp(-pred)
  # se <- se * exp(-pred)
}

# Comparing survival models
comparemods <- function(X){
  dplyr::transmute(
    X,
    sex, outcome, fut,
    LL0 = purrr::map_dbl(NullMod, logLik),
    LLBase = purrr::map_dbl(mod_base, logLik),
    NVBase = purrr::map_dbl(mod_base, \(MOD) sum(!is.na(MOD$coefficients))),
    LLBaseCl = purrr::map_dbl(mod_clus, logLik),
    NVBaseCl = purrr::map_dbl(mod_clus, \(MOD) sum(!is.na(MOD$coefficients))),
    LRTstat = 2 * abs(LLBaseCl - LLBase),
    LRTdf = NVBaseCl - NVBase,
    LRTp = stats::pchisq(q = LRTstat, df = LRTdf, lower.tail = FALSE),
    AdeqInd = (LLBase - LL0) / (LLBaseCl - LL0),
    
    CBase = purrr::map_dbl(mod_base, \(MOD) MOD[["concordance"]][["concordance"]]),
    CseBase = purrr::map_dbl(mod_base, \(MOD) MOD[["concordance"]][["std"]]),
    CBaseCl = purrr::map_dbl(mod_clus, \(MOD) MOD[["concordance"]][["concordance"]]),
    CseBaseCl = purrr::map_dbl(mod_clus, \(MOD) MOD[["concordance"]][["std"]]),
    Cdat = purrr::map2(mod_clus, mod_base, survival::concordance),
    Cdiff = purrr::map_dbl(Cdat, \(MOD) c(1, -1) %*% coef(MOD)),
    Cdiffse = purrr::map_dbl(Cdat, \(MOD) sqrt(c(1, -1) %*% vcov(MOD) %*% c(1, -1))),
    Cdiffp = 2*pnorm(-abs(Cdiff / Cdiffse)),
    Cdiff_lower = Cdiff - 1.96 * Cdiffse,
    Cdiff_upper = Cdiff + 1.96 * Cdiffse,
    
    NRI_IDI = purrr::pmap(
      list(survdf, mod_base, mod_clus, fut),
      function(DAT, MOD1, MOD2, FUT){
        NA_list <- list(NRI = NA_real_, NRI_lower = NA_real_, NRI_upper = NA_real_,
                        IDI = NA_real_, IDI_lower = NA_real_, IDI_upper = NA_real_)
        
        if (sum(DAT$outcome_value) < 5) return(NA_list)
        if (max(DAT$outcome_timeyrs) < 0.1) return(NA_list)
        actual_fut <- min(FUT, max(DAT$outcome_timeyrs))
        if (actual_fut < 0.1) return(NA_list)
        
        
        lp_base <- tryCatch(predict(MOD1, type="lp"), error=function(e) rep(NA, nrow(DAT)))
        lp_clus <- tryCatch(predict(MOD2, type="lp"), error=function(e) rep(NA, nrow(DAT)))
        if (any(is.na(lp_base)) || any(is.na(lp_clus)) || 
            any(is.infinite(lp_base)) || any(is.infinite(lp_clus))) {
          return(NA_list)
        }
        
        indata <- DAT[, c("outcome_timeyrs", "outcome_value")]
        res <- tryCatch(
          IDI.INF(
            indata = indata,
            covs0 = as.matrix(lp_base),
            covs1 = as.matrix(lp_clus),
            t0 = actual_fut,
            npert = 200
          ),
          error = function(e) {
            message("IDI.INF error: ", e$message)
            return(NULL)
          }
        )
        if (is.null(res)) return(NA_list)
        if (!all(c("point", "m1", "m2") %in% names(res))) return(NA_list)
        if (!all(c("TXI", "IDI") %in% names(res$point))) return(NA_list)
        
        
        nri_est <- res$point$TXI
        if (is.matrix(nri_est)) nri_est <- nri_est[1,1] else nri_est <- nri_est[1]
        idi_est <- res$point$IDI
        if (is.matrix(idi_est)) idi_est <- idi_est[1,1] else idi_est <- idi_est[1]
        
        nri_lower <- res$m2[names(res$m2) == "2.5%"]
        nri_lower <- if (length(nri_lower) == 0) NA_real_ else as.numeric(nri_lower)
        nri_upper <- res$m2[names(res$m2) == "97.5%"]
        nri_upper <- if (length(nri_upper) == 0) NA_real_ else as.numeric(nri_upper)
        
        idi_lower <- res$m1[names(res$m1) == "2.5%"]
        idi_lower <- if (length(idi_lower) == 0) NA_real_ else as.numeric(idi_lower)
        idi_upper <- res$m1[names(res$m1) == "97.5%"]
        idi_upper <- if (length(idi_upper) == 0) NA_real_ else as.numeric(idi_upper)
        
        list(
          NRI = as.numeric(nri_est),
          NRI_lower = nri_lower,
          NRI_upper = nri_upper,
          IDI = as.numeric(idi_est),
          IDI_lower = idi_lower,
          IDI_upper = idi_upper
        )
      }
    ),
    Cdat = NULL
  )
}


# Estimate risk at a given time
surv_to_risk <- function(mat, time, robust){
  res <- survival:::survfit.formula(
    mat[,1] ~ 1, 
    data = mat,
    weights = mat[,"weights"],
    robust = robust
  )
  res <- broom::tidy(res)
  res <- dplyr::mutate(res, estimate = 1 - estimate)
  res <- dplyr::filter(res, time <= time)
  res <- dplyr::slice_tail(res)
  res$estimate
}

# Decision curve analysis
dca <- function(formula, data, thresholds, time, weights = rep(1, nrow(data)), robust = FALSE){
  model_frame <- stats::model.frame(formula, data)
  outcome_name <- names(model_frame)[1]
  preds <- setdiff(names(model_frame), outcome_name)
  model_frame$all <- 1
  model_frame$none <- 0
  model_frame <- dplyr::mutate(
    model_frame,
    dplyr::across(
      -dplyr::all_of(outcome_name),
      ~dplyr::case_when(.x == 0 ~ 0 - .Machine$double.eps,
                        .x == 1 ~ 1 + .Machine$double.eps,
                        TRUE ~ .x)
    )
  )
  model_frame$weights <- weights
  outcome <- model_frame[[outcome_name]]
  RES <- tidyr::expand_grid(
    pred = c(preds, "all", "none"),
    threshold = thresholds
  )
  RES <- dplyr::mutate(
    RES,
    n = sum(weights),
    pos_rate = surv_to_risk(model_frame, time, robust),
    test_pos_rate = purrr::map2_dbl(
      pred, threshold,
      function(P, T, MODF){
        Pr <- MODF[,P]
        W <- MODF[,"weights"]
        TB <- wtd_table(Pr >= T, p = W)
        NPOS <- TB["TRUE"]
        if(is.na(NPOS)){ 
          return(0)
        } else {
          return(NPOS / sum(W))
        }
      },
      MODF = model_frame
    ),
    risk_rate_among_test_pos = purrr::map2_dbl(
      pred, threshold,
      function(P, T, MODF, time, robust){
        Pr <- MODF[,P]
        MODFPOS <- MODF[Pr >= T,]
        tryCatch(
          surv_to_risk(MODFPOS, time, robust),
          error = function(e) {
            if(sum(Pr >= T) == 0L){ return(0) }
            NA_real_
          }
        ) 
      },
      MODF = model_frame, time = time, robust = robust
    ),
    tp_rate = risk_rate_among_test_pos * test_pos_rate,
    fp_rate = (1 - risk_rate_among_test_pos) * test_pos_rate,
    net_benefit = tp_rate - threshold / (1 - threshold) * fp_rate
  )
  RES <- dplyr::select(RES, pred, n, threshold, pos_rate, tp_rate, fp_rate, net_benefit)
  allnb <- dplyr::filter(RES, pred == "all")
  allnb <- dplyr::select(allnb, threshold, net_benefit_all = net_benefit)
  RES <- dplyr::left_join(RES, allnb, by = "threshold")
  dplyr::mutate(
    RES,
    net_intervention_avoided = (net_benefit - net_benefit_all) /
      (threshold / (1 - threshold)),
    net_benefit_all = NULL
  )
}

# DCA
DCurvFx <- function(X){
  RES <- dplyr::transmute(
    X,
    sex, outcome, fut,
    RES1 = purrr::pmap(
      list(survdf, mod_base, mod_clus, fut),
      function(DAT, MOD1, MOD2, FUT){
        NEWDAT <- mutate(DAT, outcome_timeyrs = FUT)
        DAT$base <- 1 - survival:::predict.coxph(MOD1, NEWDAT, type = "survival")
        DAT$clus <- 1 - survival:::predict.coxph(MOD2, NEWDAT, type = "survival")
        dca(
          formula = survival::Surv(time = outcome_timeyrs, event = outcome_value) ~ 
            base + clus,
          data = DAT,
          thresholds = seq(0, .25, .01),
          time = FUT
        )
      }
    )
  )
  tidyr::unnest(RES, RES1)
}


# Logistic regression was used to model the onset of diseases for which survival time was not available—specifically, type 2 diabetes mellitus (T2DM) and chronic kidney disease (CKD) in our study.
DISEASES_long <- c("CKD","T2DM")
assocdxfx_long <- function(X){
  RES <- dplyr::mutate(
    X,
    data = purrr::map(
      data,
      function(DAT){
        DAT <- tidyr::pivot_longer(
          DAT,
          dplyr::all_of(DISEASES_long),
          names_to = "Dx_name",
          values_to = "Dx_value"
        )
        DAT <- tidyr::nest(DAT, DxDat = -Dx_name)
        # DAT <- dplyr::filter(DAT, purrr::map_dbl(DxDat, \(x) sum(x$Dx_value)) > 5)
        DAT <- dplyr::mutate(
          DAT,
          DxDat = purrr::map(
            DxDat,
            function(DXD){
              DXD <- dplyr::transmute(
                DXD,
                Dx_value,
                dplyr::across(dplyr::starts_with("prob"), \(x) ifelse(x < 1e-15, 1e-15, x)),
                dplyr::across(dplyr::starts_with("prob"), \(x) ifelse(x > (1 - 1e-15), (1 - 1e-15), x)),
                dplyr::across(dplyr::starts_with("prob"), \(x) log(x/probNSF), .names = "alr{.col}"),
                alrprobNSF = NULL,
                #dplyr::across(dplyr::starts_with("prob"), \(P) NULL),
                dplyr::across(dplyr::starts_with("prob")),
                dplyr::across(dplyr::all_of(c(BODYSIZEINDEX, COVARIATES, BIOMARKERS, MEDICATION)))
              )
            }
          )
        )
      }
    )
  )
  #XX <-  RES[[1]][[1]]
  XX <- RES %>%
    tidyr::unnest(data) %>%
    dplyr::select(sex, Dx_name, DxDat)
  XX <- dplyr::transmute(XX,
                         sex = sex,
                         outcome=Dx_name,
                         data=DxDat,
                         fut=10) 
  X1 <- dplyr::filter(XX, outcome == "T2DM")
  X1 <- dplyr::mutate(
    X1,
    survdf = purrr::map(
      data,
      function(DATA){
        MODELDAT <- dplyr::transmute(
          DATA,
          Dx_value,
          bmi,
          dplyr::across(dplyr::starts_with("alrprob")),
          dplyr::across(dplyr::starts_with(c(BIOMARKERS,COVARIATES)))
          
        )
      }
    )
  )
  
  X2 <- dplyr::filter(XX, outcome == "CKD")
  X2 <- dplyr::mutate(
    X2,
    survdf = purrr::map(
      data,
      function(DATA){
        MODELDAT <- dplyr::transmute(
          DATA,
          Dx_value,
          bmi,
          dplyr::across(dplyr::starts_with("alrprob")),
          dplyr::across(dplyr::starts_with(c(BIOMARKERS,COVARIATES)))
          
        )
      }
    )
  )    
  
  NewX <- dplyr::bind_rows(X1, X2)
  dplyr::mutate(
    NewX,
    
    NullMod = purrr::map(
      survdf, 
      ~ glm(Dx_value ~ 1, family = binomial, data = .x)
    ), 
    
    mod_base = purrr::map(
      survdf,
      ~{
        MODELDAT <- dplyr::select(.x, -dplyr::starts_with("alrprob"))
        MOD1 <- glm(Dx_value ~ ., family = binomial, data = MODELDAT)
        COEFS <- coef(MOD1)
        COEFSNA <- COEFS[is.na(COEFS)]
        MODELDAT <- dplyr::select(MODELDAT, -all_of(names(COEFSNA)))
        glm(Dx_value ~ ., family = binomial, data = MODELDAT)
      }
    ), 
    
    mod_clus = purrr::map(
      survdf,
      ~{
        MOD1 <- glm(Dx_value ~ ., family = binomial, data = .x)
        COEFS <- coef(MOD1)
        COEFSNA <- COEFS[is.na(COEFS)]
        MODELDAT <- dplyr::select(.x, -all_of(names(COEFSNA)))
        glm(Dx_value ~ ., family = binomial, data = MODELDAT)
      }
    ) 
  )
}

# Comparing logistic models
comparemods_CKDDM <- function(X){
  library(pROC)
  library(nricens)
  library(ResourceSelection)
  
  calib_slope_intercept <- function(event, pred, g = 10) {
    
    if (sum(event) < 5 || sum(1-event) < 5) {
      return(list(slope = NA_real_, intercept = NA_real_))
    }
    
    cuts <- unique(quantile(pred, probs = seq(0, 1, length.out = g+1), na.rm = TRUE))
    if (length(cuts) < 2) {
      return(list(slope = NA_real_, intercept = NA_real_))
    }
    group <- cut(pred, breaks = cuts, include.lowest = TRUE)
    levels_group <- levels(group)
    obs_risk <- numeric(length(levels_group))
    exp_risk <- numeric(length(levels_group))
    for (i in seq_along(levels_group)) {
      idx <- which(group == levels_group[i])
      if (length(idx) < 5) {
        obs_risk[i] <- NA
        exp_risk[i] <- NA
        next
      }
      obs_risk[i] <- mean(event[idx], na.rm = TRUE)
      exp_risk[i] <- mean(pred[idx], na.rm = TRUE)
    }
    valid <- !is.na(obs_risk) & !is.na(exp_risk)
    if (sum(valid) < 3) {
      return(list(slope = NA_real_, intercept = NA_real_))
    }
    lm_fit <- lm(obs_risk[valid] ~ exp_risk[valid])
    slope <- coef(lm_fit)[2]
    intercept <- coef(lm_fit)[1]
    return(list(slope = as.numeric(slope), intercept = as.numeric(intercept)))
  }
  
  dplyr::transmute(
    X,
    sex, outcome, fut,
    LL0 = purrr::map_dbl(NullMod, logLik),
    LLBase = purrr::map_dbl(mod_base, logLik),
    NVBase = purrr::map_dbl(mod_base, \(MOD) sum(!is.na(MOD$coefficients))),
    LLBaseCl = purrr::map_dbl(mod_clus, logLik),
    NVBaseCl = purrr::map_dbl(mod_clus, \(MOD) sum(!is.na(MOD$coefficients))),
    LRTstat = 2 * abs(LLBaseCl - LLBase),
    LRTdf = NVBaseCl - NVBase,
    LRTp = stats::pchisq(q = LRTstat, df = LRTdf, lower.tail = FALSE),
    AdeqInd = (LLBase - LL0) / (LLBaseCl - LL0),
    
    
    AUC_test = purrr::pmap(
      list(data, mod_base, mod_clus),
      function(D1, D2, D3){
        p1 <- predict(D2, newdata = D1, type = "response")
        p2 <- predict(D3, newdata = D1, type = "response")
        valid <- complete.cases(D1$Dx_value, p1, p2)
        if (!any(valid)) {
          return(list(auc_base = NA_real_, auc_clus = NA_real_,
                      se_base = NA_real_, se_clus = NA_real_,
                      diff = NA_real_, se_diff = NA_real_,
                      ci_lower = NA_real_, ci_upper = NA_real_,
                      p_value = NA_real_))
        }
        D1 <- D1[valid, ]
        p1 <- p1[valid]
        p2 <- p2[valid]
        roc1 <- roc(D1$Dx_value, p1, quiet = TRUE)
        roc2 <- roc(D1$Dx_value, p2, quiet = TRUE)
        test <- tryCatch(
          roc.test(roc1, roc2, method = "delong", paired = TRUE),
          error = function(e) NULL
        )
        if (is.null(test)) {
          return(list(auc_base = as.numeric(auc(roc1)),
                      auc_clus = as.numeric(auc(roc2)),
                      se_base = sqrt(as.numeric(var(roc1))),
                      se_clus = sqrt(as.numeric(var(roc2))),
                      diff = NA_real_, se_diff = NA_real_,
                      ci_lower = NA_real_, ci_upper = NA_real_,
                      p_value = NA_real_))
        }
        if (length(test$estimate) == 1) {
          diff_auc <- test$estimate
        } else {
          diff_auc <- test$estimate[1] - test$estimate[2]
        }
        if (!is.null(test$se)) {
          se_diff <- test$se
        } else {
          se_diff <- (test$conf.int[2] - test$conf.int[1]) / (2 * 1.96)
        }
        list(
          auc_base = as.numeric(auc(roc1)),
          auc_clus = as.numeric(auc(roc2)),
          se_base  = sqrt(as.numeric(var(roc1))),
          se_clus  = sqrt(as.numeric(var(roc2))),
          diff     = diff_auc,
          se_diff  = se_diff,
          ci_lower = test$conf.int[1],
          ci_upper = test$conf.int[2],
          p_value  = test$p.value
        )
      }
    ),
    CBase = purrr::map_dbl(AUC_test, "auc_base"),
    CseBase = purrr::map_dbl(AUC_test, "se_base"),
    CBaseCl = purrr::map_dbl(AUC_test, "auc_clus"),
    CseBaseCl = purrr::map_dbl(AUC_test, "se_clus"),
    Cdiff = purrr::map_dbl(AUC_test, "diff"),
    Cdiffse = purrr::map_dbl(AUC_test, "se_diff"),
    Cdiffp = purrr::map_dbl(AUC_test, "p_value"),
    Cdiff_lower = purrr::map_dbl(AUC_test, "ci_lower"),
    Cdiff_upper = purrr::map_dbl(AUC_test, "ci_upper"),
    
    
    NRI_IDI = purrr::pmap(
      list(data, mod_base, mod_clus),
      function(D1, D2, D3){
        NA_list <- list(NRI = NA_real_, NRI_lower = NA_real_, NRI_upper = NA_real_,
                        IDI = NA_real_, IDI_lower = NA_real_, IDI_upper = NA_real_)
        p1 <- predict(D2, newdata = D1, type = "response")
        p2 <- predict(D3, newdata = D1, type = "response")
        valid <- complete.cases(D1$Dx_value, p1, p2)
        if (!any(valid)) return(NA_list)
        D1 <- D1[valid, ]
        p1 <- p1[valid]
        p2 <- p2[valid]
        event <- D1$Dx_value
        n_case <- sum(event == 1)
        n_ctrl <- sum(event == 0)
        if (n_case < 5 || n_ctrl < 5) return(NA_list)
        
        
        cuts <- quantile(p1, probs = c(1/3, 2/3), na.rm = TRUE)
        if (cuts[1] == cuts[2]) {
          cuts <- quantile(p1, probs = c(0.25, 0.75), na.rm = TRUE)
        }
        if (length(unique(cuts)) < 2) {
          cuts <- c(0.1, 0.2)
        }
        res_nri <- tryCatch(
          nribin(event = event, p.std = p1, p.new = p2,
                 updown = "category", cut = cuts, niter = 100),
          error = function(e) NULL
        )
        if (is.null(res_nri)) {
          nri <- nri_lower <- nri_upper <- NA_real_
        } else {
          if (!is.null(res_nri$nri) && is.data.frame(res_nri$nri)) {
            nri <- as.numeric(res_nri$nri[1, "Estimate"])
            nri_lower <- as.numeric(res_nri$nri[1, "Lower"])
            nri_upper <- as.numeric(res_nri$nri[1, "Upper"])
          } else {
            nri <- nri_lower <- nri_upper <- NA_real_
          }
        }
        
        
        idi_est <- mean(p2[event == 1]) - mean(p1[event == 1]) - 
          (mean(p2[event == 0]) - mean(p1[event == 0]))
        boot_idi <- replicate(100, {
          idx_case <- sample(which(event == 1), replace = TRUE)
          idx_ctrl <- sample(which(event == 0), replace = TRUE)
          p1_case_b <- p1[idx_case]
          p2_case_b <- p2[idx_case]
          p1_ctrl_b <- p1[idx_ctrl]
          p2_ctrl_b <- p2[idx_ctrl]
          mean(p2_case_b) - mean(p1_case_b) - (mean(p2_ctrl_b) - mean(p1_ctrl_b))
        })
        idi_lower <- quantile(boot_idi, 0.025, na.rm = TRUE)
        idi_upper <- quantile(boot_idi, 0.975, na.rm = TRUE)
        if (is.na(idi_lower) || is.na(idi_upper)) {
          idi_est <- idi_lower <- idi_upper <- NA_real_
        }
        
        if (all(is.na(c(nri, nri_lower, nri_upper, idi_est, idi_lower, idi_upper)))) {
          return(NA_list)
        }
        list(
          NRI = nri,
          NRI_lower = nri_lower,
          NRI_upper = nri_upper,
          IDI = idi_est,
          IDI_lower = idi_lower,
          IDI_upper = idi_upper
        )
      }
    ),
    
    
    HL_p = purrr::map2_dbl(
      data, mod_base,
      function(D1, D2){
        pred <- predict(D2, newdata = D1, type = "response")
        valid <- complete.cases(D1$Dx_value, pred)
        if (!any(valid)) return(NA_real_)
        D1 <- D1[valid, ]
        pred <- pred[valid]
        g <- min(10, floor(nrow(D1)/5))
        if (g < 2) return(NA_real_)
        hl <- tryCatch(hoslem.test(D1$Dx_value, pred, g = g), error = function(e) NULL)
        if (is.null(hl)) NA_real_ else hl$p.value
      }
    ),
    HL_p_clus = purrr::map2_dbl(
      data, mod_clus,
      function(D1, D2){
        pred <- predict(D2, newdata = D1, type = "response")
        valid <- complete.cases(D1$Dx_value, pred)
        if (!any(valid)) return(NA_real_)
        D1 <- D1[valid, ]
        pred <- pred[valid]
        g <- min(10, floor(nrow(D1)/5))
        if (g < 2) return(NA_real_)
        hl <- tryCatch(hoslem.test(D1$Dx_value, pred, g = g), error = function(e) NULL)
        if (is.null(hl)) NA_real_ else hl$p.value
      }
    ),
    
    
    Calib_res = purrr::pmap(
      list(data, mod_base, mod_clus),
      function(D1, D2, D3){
        p1 <- predict(D2, newdata = D1, type = "response")
        p2 <- predict(D3, newdata = D1, type = "response")
        valid <- complete.cases(D1$Dx_value, p1, p2)
        if (!any(valid)) {
          return(list(base_slope = NA_real_, base_intercept = NA_real_,
                      clus_slope = NA_real_, clus_intercept = NA_real_,
                      diff_slope = NA_real_, diff_lower = NA_real_, diff_upper = NA_real_,
                      diff_p = NA_real_))
        }
        D1 <- D1[valid, ]
        p1 <- p1[valid]
        p2 <- p2[valid]
        event <- D1$Dx_value
        if (sum(event) < 5 || sum(1-event) < 5) {
          return(list(base_slope = NA_real_, base_intercept = NA_real_,
                      clus_slope = NA_real_, clus_intercept = NA_real_,
                      diff_slope = NA_real_, diff_lower = NA_real_, diff_upper = NA_real_,
                      diff_p = NA_real_))
        }
        
        cal_base <- calib_slope_intercept(event, p1)
        cal_clus <- calib_slope_intercept(event, p2)
        
        B <- 100
        diff_bs <- replicate(B, {
          idx <- sample(1:nrow(D1), replace = TRUE)
          event_b <- event[idx]
          p1_b <- p1[idx]
          p2_b <- p2[idx]
          cal1 <- calib_slope_intercept(event_b, p1_b)
          cal2 <- calib_slope_intercept(event_b, p2_b)
          if (is.na(cal1$slope) || is.na(cal2$slope)) return(NA)
          cal1$slope - cal2$slope
        })
        diff_bs <- diff_bs[!is.na(diff_bs)]
        if (length(diff_bs) < 30) {
          diff_slope <- diff_lower <- diff_upper <- diff_p <- NA_real_
        } else {
          diff_slope <- cal_base$slope - cal_clus$slope
          diff_lower <- quantile(diff_bs, 0.025)
          diff_upper <- quantile(diff_bs, 0.975)
          prop_gt <- mean(diff_bs > 0)
          prop_lt <- mean(diff_bs < 0)
          diff_p <- 2 * min(prop_gt, prop_lt)
        }
        list(
          base_slope = cal_base$slope,
          base_intercept = cal_base$intercept,
          clus_slope = cal_clus$slope,
          clus_intercept = cal_clus$intercept,
          diff_slope = diff_slope,
          diff_lower = diff_lower,
          diff_upper = diff_upper,
          diff_p = diff_p
        )
      }
    ),
    base_slope = purrr::map_dbl(Calib_res, "base_slope"),
    base_intercept = purrr::map_dbl(Calib_res, "base_intercept"),
    base_p = HL_p,
    clus_slope = purrr::map_dbl(Calib_res, "clus_slope"),
    clus_intercept = purrr::map_dbl(Calib_res, "clus_intercept"),
    clus_p = HL_p_clus,
    diff_slope = purrr::map_dbl(Calib_res, "diff_slope"),
    diff_lower = purrr::map_dbl(Calib_res, "diff_lower"),
    diff_upper = purrr::map_dbl(Calib_res, "diff_upper"),
    diff_p = purrr::map_dbl(Calib_res, "diff_p"),

    AUC_test = NULL,
    Calib_res = NULL,
    HL_p = NULL,
    HL_p_clus = NULL
  )
}

# Extracting coefficients of models
survcoefx <- function(X){
  RES <- dplyr::select(X, sex, outcome, fut, starts_with("mod_"))
  RES <- tidyr::pivot_longer(
    RES, 
    starts_with("mod_"), 
    names_to = c(".value", "model"), 
    names_sep = "_"
  )
  RES <- dplyr::mutate(
    RES,
    mod = purrr::map(
      mod, 
      function(MOD){
        tibble::tibble(
          estimates = list(coef(MOD)),
          varcovmat = list(vcov(MOD)),
          Means = list(MOD$means)
          # Afit = list(
          #   survival:::agsurv(
          #     MOD$y, 
          #     model.matrix(MOD) - rep(MOD$means, each = nrow(MOD$y)), 
          #     rep(1.0, nrow(MOD$y)), 
          #     exp(MOD$linear.predictors), 
          #     3, 3
          #   )
          # )
        )
      }
    )
  )
  tidyr::unnest(RES, mod)
}

#the number of incident cases of T2DM and CKD across clusters
prevalent_stats <- function(X, diseases = c("CKD", "T2DM")){
  RES <- dplyr::transmute(
    X,
    sex,
    stats = purrr::map(
      data,
      function(DAT){
        prob_cols <- grep("^prob", names(DAT), value = TRUE)
        DAT$hard_cluster <- prob_cols[apply(DAT[, prob_cols, drop = FALSE], 1, which.max)]
        
        RES1 <- tidyr::expand_grid(
          Cluster = prob_cols,
          Disease = diseases
        )
        RES1 <- dplyr::mutate(
          RES1,
          #probability weighted
          w_Ncases = purrr::map2_dbl(
            Cluster, Disease,
            function(CL, DIS, D){
              sum(D[[DIS]] * D[[CL]], na.rm = TRUE)
            },
            D = DAT
          ),
          w_Nnoncases = purrr::map2_dbl(
            Cluster, Disease,
            function(CL, DIS, D){
              sum((1 - D[[DIS]]) * D[[CL]], na.rm = TRUE)
            },
            D = DAT
          ),
          #Hard classification
          hard_Ncases = purrr::map2_dbl(
            Cluster, Disease,
            function(CL, DIS, D){
              sum(D[[DIS]] == 1 & D$hard_cluster == CL, na.rm = TRUE)
            },
            D = DAT
          ),
          hard_Nnoncases = purrr::map2_dbl(
            Cluster, Disease,
            function(CL, DIS, D){
              sum(D[[DIS]] == 0 & D$hard_cluster == CL, na.rm = TRUE)
            },
            D = DAT
          )
        )
        return(RES1)
      }
    )
  )
  tidyr::unnest(RES, stats)
}

#evaluate model calibration for both T2DM and CKD.
calibration_analysis <- function(model1, model2 = NULL, data, time_point, g = 10, B = 500, seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  
  .cal_single <- function(mod, dat, tp, grp) {
    if (sum(dat$outcome_value) < 5) {
      return(list(slope = NA_real_, intercept = NA_real_, p.value = NA_real_, groups = NULL))
    }
    max_time <- max(dat$outcome_timeyrs)
    actual_time <- min(tp, max_time)
    if (actual_time < 0.1) {
      return(list(slope = NA_real_, intercept = NA_real_, p.value = NA_real_, groups = NULL))
    }
    
    newdata <- dat
    newdata$outcome_timeyrs <- actual_time
    surv_prob <- tryCatch(predict(mod, newdata = newdata, type = "survival"),
                          error = function(e) rep(NA, nrow(dat)))
    if (any(is.na(surv_prob))) {
      return(list(slope = NA_real_, intercept = NA_real_, p.value = NA_real_, groups = NULL))
    }
    risk <- 1 - surv_prob
    
    cuts <- unique(quantile(risk, probs = seq(0, 1, length.out = grp + 1), na.rm = TRUE))
    if (length(cuts) < 2) {
      return(list(slope = NA_real_, intercept = NA_real_, p.value = NA_real_, groups = NULL))
    }
    group_labels <- cut(risk, breaks = cuts, include.lowest = TRUE)
    group_levels <- levels(group_labels)
    
    obs_risk <- numeric(length(group_levels))
    exp_risk <- numeric(length(group_levels))
    n_events <- integer(length(group_levels))
    n_total <- integer(length(group_levels))
    
    for (i in seq_along(group_levels)) {
      idx <- which(group_labels == group_levels[i])
      if (length(idx) < 5) {
        obs_risk[i] <- NA; exp_risk[i] <- NA; n_events[i] <- NA; n_total[i] <- NA
        next
      }
      sub <- dat[idx, ]
      km_fit <- tryCatch(survfit(Surv(outcome_timeyrs, outcome_value) ~ 1, data = sub),
                         error = function(e) NULL)
      if (is.null(km_fit)) {
        obs_risk[i] <- NA
      } else {
        sum_obj <- summary(km_fit, times = actual_time, extend = TRUE)
        if (length(sum_obj$surv) == 0) {
          obs_risk[i] <- 1 - tail(km_fit$surv, 1)
        } else {
          obs_risk[i] <- 1 - sum_obj$surv[1]
        }
      }
      exp_risk[i] <- mean(risk[idx], na.rm = TRUE)
      n_events[i] <- sum(sub$outcome_value)
      n_total[i] <- length(idx)
    }
    
    valid <- !is.na(obs_risk) & !is.na(exp_risk)
    if (sum(valid) < 3) {
      return(list(slope = NA_real_, intercept = NA_real_, p.value = NA_real_, groups = NULL))
    }
    
    lm_fit <- lm(obs_risk[valid] ~ exp_risk[valid])
    slope <- coef(lm_fit)[2]
    intercept <- coef(lm_fit)[1]
    
    exp_events <- exp_risk[valid] * n_total[valid]
    obs_events_est <- obs_risk[valid] * n_total[valid]
    chi2 <- sum((obs_events_est - exp_events)^2 / (exp_events * (1 - exp_risk[valid]) + 1e-6), na.rm = TRUE)
    df <- sum(valid) - 2
    if (df < 1) df <- 1
    p_value <- pchisq(chi2, df = df, lower.tail = FALSE)
    
    groups_df <- data.frame(group = group_levels[valid],
                            n_total = n_total[valid],
                            n_events = n_events[valid],
                            exp_risk = exp_risk[valid],
                            obs_risk = obs_risk[valid],
                            stringsAsFactors = FALSE)
    
    list(slope = as.numeric(slope),
         intercept = as.numeric(intercept),
         p.value = as.numeric(p_value),
         groups = groups_df)
  }
  
  res1 <- .cal_single(model1, data, time_point, g)
  
  if (is.null(model2)) {
    return(res1)
  }
  
  res2 <- .cal_single(model2, data, time_point, g)
  
  comp <- list(diff = NA_real_, lower = NA_real_, upper = NA_real_, p.value = NA_real_, B_eff = NA_real_)
  if (!is.na(res1$slope) && !is.na(res2$slope)) {
    
    diff_bs <- replicate(B, {
      idx <- sample(1:nrow(data), replace = TRUE)
      boot_dat <- data[idx, ]
      cal1_b <- tryCatch(.cal_single(model1, boot_dat, time_point, g)$slope, error = function(e) NA)
      cal2_b <- tryCatch(.cal_single(model2, boot_dat, time_point, g)$slope, error = function(e) NA)
      if (is.na(cal1_b) || is.na(cal2_b)) return(NA)
      cal1_b - cal2_b
    })
    diff_bs <- diff_bs[!is.na(diff_bs)]
    if (length(diff_bs) >= 100) {
      lower <- quantile(diff_bs, 0.025, na.rm = TRUE)
      upper <- quantile(diff_bs, 0.975, na.rm = TRUE)
      prop_gt <- mean(diff_bs > 0, na.rm = TRUE)
      prop_lt <- mean(diff_bs < 0, na.rm = TRUE)
      p_val <- 2 * min(prop_gt, prop_lt)
      comp <- list(diff = res1$slope - res2$slope,
                   lower = as.numeric(lower),
                   upper = as.numeric(upper),
                   p.value = as.numeric(p_val),
                   B_eff = length(diff_bs))
    } else {
      warning("The number of successful Bootstrap iterations is less than 100.")
    }
  }
  
  list(model1 = res1,
       model2 = res2,
       comparison = comp)
}

#Calculate the DCA for the T2DM and CKD models
dca_manual <- function(predictions, outcome, thresholds, weights = NULL, pred_name = "model") {
  if (is.null(weights)) weights <- rep(1, length(outcome))
  valid <- complete.cases(predictions, outcome, weights)
  if (sum(valid) == 0) {
    return(tibble::tibble(pred = character(0), threshold = numeric(0), net_benefit = numeric(0),
                          tp_rate = numeric(0), fp_rate = numeric(0), pos_rate = numeric(0),
                          net_intervention_avoided = numeric(0)))
  }
  predictions <- predictions[valid]
  outcome <- outcome[valid]
  weights <- weights[valid]
  n_total <- sum(weights)
  prevalence <- sum(outcome * weights) / n_total
  
  res <- data.frame(threshold = thresholds)
  res$n <- n_total
  for (i in seq_along(thresholds)) {
    t <- thresholds[i]
    pred_bin <- as.numeric(predictions >= t)
    tp <- sum((outcome == 1) * pred_bin * weights, na.rm = TRUE)
    fp <- sum((outcome == 0) * pred_bin * weights, na.rm = TRUE)
    nb <- (tp / n_total) - (fp / n_total) * (t / (1 - t))
    # treat_all
    nb_all <- prevalence - (1 - prevalence) * t / (1 - t)
    net_intervention_avoided <- (nb - nb_all) / (t / (1 - t))
    res[i, "net_benefit"] <- nb
    res[i, "tp_rate"] <- tp / n_total
    res[i, "fp_rate"] <- fp / n_total
    res[i, "pos_rate"] <- sum(pred_bin * weights, na.rm = TRUE) / n_total
    res[i, "net_intervention_avoided"] <- net_intervention_avoided
  }
  res$pred <- pred_name
  return(tibble::as_tibble(res))
}

DCurvFx_logistic <- function(X){
  RES <- dplyr::transmute(
    X,
    sex, outcome, fut = NA_real_,
    RES1 = purrr::pmap(
      list(data, mod_base, mod_clus),
      function(DAT, MOD1, MOD2){
        thresholds <- seq(0, .25, .01)
        base_pred <- predict(MOD1, newdata = DAT, type = "response")
        clus_pred <- predict(MOD2, newdata = DAT, type = "response")
        nb_base <- dca_manual(base_pred, DAT$Dx_value, thresholds, pred_name = "base")
        nb_clus <- dca_manual(clus_pred, DAT$Dx_value, thresholds, pred_name = "clus")
        res <- dplyr::bind_rows(nb_base, nb_clus)
        
        prevalence <- mean(DAT$Dx_value, na.rm = TRUE)
        nb_all <- prevalence - (1 - prevalence) * thresholds / (1 - thresholds)
        nb_none <- rep(0, length(thresholds))
        ref <- data.frame(
          pred = c(rep("treat_all", length(thresholds)), rep("treat_none", length(thresholds))),
          threshold = rep(thresholds, 2),
          net_benefit = c(nb_all, nb_none),
          tp_rate = c(rep(prevalence, length(thresholds)), rep(0, length(thresholds))),
          fp_rate = c(rep(1 - prevalence, length(thresholds)), rep(0, length(thresholds))),
          pos_rate = c(rep(1, length(thresholds)), rep(0, length(thresholds))),
          net_intervention_avoided = c(rep(0, length(thresholds)), rep(0, length(thresholds)))
        )
        res <- dplyr::bind_rows(res, ref)
        return(res)
      }
    )
  )
  tidyr::unnest(RES, RES1)
}
