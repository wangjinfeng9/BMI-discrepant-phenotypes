#3.8-year clustering transformation and 10-year CVD outcome
library(haven)
library(dplyr)
library(survival)
library(dplyr)
library(tidyr)
library(broom)
library(openxlsx)
library(stringr)
library(purrr)

Data<- read.csv("../data/Data_4C.csv") #should include sex, age, bmi, smoking, sbp, dbp, hdl, fg, scr, ldl, tg, and CVD outcomes
data<- read.csv("../data/4C_3yr with baseline.csv")

alldata <- Data %>%
  dplyr::inner_join(data %>% 
                      dplyr::select(eid, Group), by = "eid") %>%
  filter(antihypertensive!=1 & lipidlower_drug!=1)  %>%
  filter(cvd15==0)

# cox model
perform_cox_analysis_by_sex <- function(data, ref_group, comp_group, outcome_type, sex_group) {

  sex_data <- data %>% filter(sex == sex_group)
  
  if (outcome_type == "CVD") {
    outcome_var <- "CVD"
    time_var <- "timecvd21"
  } else if (outcome_type == "MI") {
    outcome_var <- "MI"
    time_var <- "timemi21"
  } else if (outcome_type == "Stroke") {
    outcome_var <- "Stroke"
    time_var <- "timestroke21"
  } else {
    stop("error")
  }
  
  ref_data <- sex_data %>% filter(Group == ref_group)
  comp_data <- sex_data %>% filter(Group == comp_group)
  
  analysis_data <- bind_rows(
    ref_data %>% mutate(group = 0),  
    comp_data %>% mutate(group = 1)   
  )
  
  if (nrow(ref_data) < 10 | nrow(comp_data) < 10) {
    cat("    ", sex_group, "Insufficient sample size, skipping:", ref_group, "vs", comp_group, "-", outcome_type, "\n")
    return(NULL)
  }
  
  event_count_ref <- sum(ref_data[[outcome_var]], na.rm = TRUE)
  event_count_comp <- sum(comp_data[[outcome_var]], na.rm = TRUE)
  
  if (event_count_ref < 5 | event_count_comp < 5) {
    cat("    ", sex_group, "Insufficient event count, skipping:", ref_group, "vs", comp_group, "-", outcome_type, "\n")
    return(NULL)
  }
  
  #model1
  formula1 <- as.formula(paste("Surv(", time_var, ", ", outcome_var, ") ~ group + age"))
  tryCatch({
    model1 <- coxph(formula1, data = analysis_data)
    sum_model1 <- summary(model1)
  }, error = function(e) {
    cat("    ", sex_group, "model1 failed:", e$message, "\n")
    return(NULL)
  })
  
  # model2
  formula2 <- as.formula(paste("Surv(", time_var, ", ", outcome_var, ") ~ group + smoking + age + bmi + sbp + dbp + hdl + fg + scr + ldl + tg"))
  tryCatch({
    model2 <- coxph(formula2, data = analysis_data)
    sum_model2 <- summary(model2)
  }, error = function(e) {
    cat("    ", sex_group, "model1 failed:", e$message, "\n")
    return(NULL)
  })
  
  extract_cox_results <- function(model_summary, model_name) {
    group_coef <- model_summary$coefficients["group", ]
    conf_int <- model_summary$conf.int["group", ]
    
    results <- data.frame(
      sex = sex_group,
      ref_group = ref_group,
      comp_group = comp_group,
      outcome = outcome_type,
      model = model_name,
      n_total = model_summary$n,
      n_events = model_summary$nevent,
      hr = conf_int[1],
      hr_lower = conf_int[3],
      hr_upper = conf_int[4],
      coef = group_coef[1],
      se = group_coef[3],
      z = group_coef[4],
      p_value = group_coef[5],
      stringsAsFactors = FALSE
    )
    
    return(results)
  }
  
  results <- bind_rows(
    extract_cox_results(sum_model1, "Model 1 (age adjusted)"),
    extract_cox_results(sum_model2, "Model 2 (fully adjusted)")
  )
  
  desc_stats <- data.frame(
    sex = sex_group,
    ref_group = ref_group,
    comp_group = comp_group,
    outcome = outcome_type,
    ref_n = nrow(ref_data),
    comp_n = nrow(comp_data),
    ref_events = event_count_ref,
    comp_events = event_count_comp,
    ref_event_rate = event_count_ref / nrow(ref_data),
    comp_event_rate = event_count_comp / nrow(comp_data),
    ref_mean_followup = mean(ref_data[[time_var]], na.rm = TRUE),
    comp_mean_followup = mean(comp_data[[time_var]], na.rm = TRUE),
    ref_mean_age = mean(ref_data$age, na.rm = TRUE),
    comp_mean_age = mean(comp_data$age, na.rm = TRUE)
  )
  
  return(list(results = results, desc_stats = desc_stats))
}

get_reference_groups <- function(groups) {
  reference_groups <- c()

  if ("NSF_NSF" %in% groups) {
    reference_groups <- c(reference_groups, "NSF_NSF")
  }

  pattern_same <- "^(\\w+)_\\1$"
  same_groups <- groups[grepl(pattern_same, groups)]
  same_groups <- same_groups[same_groups != "NSF_NSF"]

  reference_groups <- c(reference_groups, same_groups)

  return(reference_groups)
}

get_comparison_groups <- function(ref_group, all_groups) {
  if (ref_group == "NSF_NSF") {
    comparison_groups <- all_groups[grepl("^NSF_", all_groups) & all_groups != "NSF_NSF"]
  } else {

    prefix <- str_extract(ref_group, "^\\w+(?=_)")

    comparison_groups <- all_groups[grepl(paste0("^", prefix, "_"), all_groups) & all_groups != ref_group]
  }

  return(comparison_groups)
}

groups <- unique(alldata$Group)
sex_groups <- unique(alldata$sex)
outcomes <- c("CVD", "MI", "Stroke")

reference_groups <- get_reference_groups(groups)
print(reference_groups)

all_cox_results <- list()
all_desc_stats <- list()

for (sex_group in sex_groups) {
  cat("\n===sex:", sex_group, "===\n")
  
  for (ref_group in reference_groups) {
    cat("\nref_group:", ref_group, "\n")
    comparison_groups <- get_comparison_groups(ref_group, groups)
    
    if (length(comparison_groups) == 0) {
      cat("null\n")
      next
    }
    
    cat("comp_group:", paste(comparison_groups, collapse = ", "), "\n")
    
    for (outcome_type in outcomes) {
      cat("outcome:", outcome_type, "\n")
      
      outcome_results <- list()
      outcome_desc_stats <- list()
      
      for (comp_group in comparison_groups) {
        cat("comparing:", ref_group, "vs", comp_group, "\n")
        
        result <- perform_cox_analysis_by_sex(alldata, ref_group, comp_group, outcome_type, sex_group)
        
        if (!is.null(result)) {
          comparison_name <- paste(ref_group, "vs", comp_group, sep = "_")
          outcome_results[[comparison_name]] <- result$results
          outcome_desc_stats[[comparison_name]] <- result$desc_stats
          
          all_cox_results[[paste(sex_group, comparison_name, outcome_type, sep = "_")]] <- result$results
          all_desc_stats[[paste(sex_group, comparison_name, outcome_type, sep = "_")]] <- result$desc_stats
        }
      }
    }
  }
}

if (length(all_cox_results) > 0) {
  all_results_combined <- bind_rows(all_cox_results)
  all_desc <- bind_rows(all_desc_stats)
  
  model2_results <- all_results_combined %>%
    filter(model == "Model 2 (fully adjusted)")
  
  if (nrow(model2_results) > 0) {
    comparison_data <- model2_results %>%
      dplyr::select(sex, ref_group, comp_group, outcome, hr, hr_lower, hr_upper, p_value) %>%
      mutate(
        comparison = paste(ref_group, "vs", comp_group),
        HR_95CI = sprintf("%.2f (%.2f-%.2f)", hr, hr_lower, hr_upper)
      ) %>%
      dplyr::select(sex, outcome, comparison, HR_95CI, p_value) %>%
      spread(key = sex, value = HR_95CI)
  }
}

merged_data <- model2_results %>%
  left_join(all_desc, by = c("sex", "ref_group", "comp_group", "outcome"))

merged_data <- merged_data %>%
  filter(str_detect(comp_group, "NSF")) %>%
  mutate(Facet = str_remove_all(comp_group, "NSF|_"))

write.csv(merged_data,"../data/Cox result.csv")
