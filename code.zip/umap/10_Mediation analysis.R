#Mediation analysis
library(tidyverse)
library(mediation)
library("bruceR")
library(dplyr)

metabdata <- read.csv("../data/metabolites.csv")
clusdata <- read.csv("../data/4C_3.8yr_cluster_results.csv")
clindata <- read.csv("../data/Data_4C.csv")
#clindata includes sex, lifestyles(smoking, drinking, physical activity, sleep time),baseline diseases (diabetes, hypertension, hyperlipidemia)
combined <- metabdata %>%
  inner_join(clusdata, by = "eid") %>%
  inner_join(clindata, by = "eid")

target_col_names <- colnames(combined)[7:11]#The column where the 3.8-year clustering probability is located
combined <- combined %>%
  mutate(across(all_of(target_col_names),
                ~ ifelse(is.na(.),
                         NA,
                         log(./NSF)),
                .names = "alr_{.col}_15"))

analyseData <- subset(combined, sex == "Female")#When analyzing the data for males, it should be changed to "Male".

analyseData[,c("smoking","drinking","physical activity",
               "diabetes", "hypertension", "hyperlipidemia")] <- lapply(analyseData[,c("smoking","drinking","physical activity",
                                                                                       "diabetes", "hypertension", "hyperlipidemia")],as.factor)
M.names <- colnames(analyseData[c(3:142)])#The column where the metabolite variables are located
X.names <- colnames(analyseData)[c(148:151)]#The column where the lifestyles are located
y_names <- colnames(analyseData[c(152:155)])#The column where the "alr_{.col}_15" are located

results <- data.frame()

total_models <- length(y_names) * length(X.names) * length(M.names)
pb_total <- txtProgressBar(min = 0, max = total_models, style = 3)

k <- 1
for (y_var in y_names) {
  
  cat("\nanalysing y:", y_var, "\n")
  
  n_models <- length(X.names) * length(M.names)
  pb <- txtProgressBar(min = 0, max = n_models, style = 3)
  
  for (j in X.names) {
    for (i in M.names) {
      
      suppressMessages({
        invisible(capture.output({
          result_obj <- PROCESS(analyseData, 
                                x = j, 
                                y = y_var,  
                                meds = i,
                                covs = c("diabetes", "hypertension", "hyperlipidemia"),
                                ci = "boot", 
                                nsim = 500, 
                                seed = 1)
        }))
      })
      
      temp <- result_obj[["results"]][[1]][["mediation"]]
      temp$y <- y_var  
      temp$mediator <- i
      temp$x <- j
      
      results <- rbind(results, temp)
      
      setTxtProgressBar(pb, (which(X.names == j)-1)*length(M.names) + which(M.names == i))
      setTxtProgressBar(pb_total, k)
      k <- k + 1
    }
  }
  
  close(pb)
}

close(pb_total)

write.csv(results, "mediation_results_female.csv", row.names = T)

#Merge data and correct p-values
process_mediation <- function(file_path, sex_label) {

  med_df <- read.csv(file_path, stringsAsFactors = FALSE)
  
  med_df$rownum <- seq_len(nrow(med_df))
  colnames(med_df)[1] <- "Type"
  if ("X.Boot.95..CI." %in% colnames(med_df)) {
    colnames(med_df)[which(colnames(med_df) == "X.Boot.95..CI.")] <- "BootCI"
  }
  
  med_df <- med_df %>%
    group_by(y, x) %>%
    mutate(
      p.adj = ifelse(grepl("Indirect", Type), p.adjust(p, method = "fdr"), p)
    ) %>%
    ungroup()
  
  indirect <- med_df %>%
    filter(grepl("Indirect", Type), p < 0.05) %>%
    dplyr::select(-Type)
  
  total <- med_df %>%
    filter(grepl("Total", Type)) %>%
    dplyr::select(y, mediator, x, Total = Effect)
  
  result <- indirect %>%
    left_join(total, by = c("y", "mediator", "x"))
  
  result$Prop. <- result$Effect / result$Total
  
  result$y <- gsub("^alr_", "", result$y)
  result$y <- gsub("_15$", "", result$y)
  
  marker <- read.csv("../data/metabolites_marker.csv", 
                     stringsAsFactors = FALSE)
  result <- result %>%
    left_join(marker %>% dplyr::select(metabolites_name, TL1),
              by = c("mediator" = "metabolites_name"))
  
  result$order <- result$rownum
  
  output <- result %>%
    arrange(TL1, metabolites_name) %>%
    dplyr::select(x, metabolites_name, y, Effect, S.E., LLCI, ULCI, p, p.adj, 
                  Total, Prop., TL1) %>%
    filter(!is.na(metabolites_name), Prop. > 0.05 & Prop. < 1)
  
  output$sex <- sex_label
  return(output)
}

male_output <- process_mediation(
  "../data/mediation_results_male.csv",
  "Male"
)

female_output <- process_mediation(
  "../data/mediation_results_female.csv",
  "Female"
)

combined <- bind_rows(male_output, female_output)
data <- combined %>% arrange(TL1,metabolites_name)

write.csv(data, "../data/mediation_combined_sex_fdr.csv", row.names = FALSE)

